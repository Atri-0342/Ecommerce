const { Schema, model } = require("mongoose");

const orderSchema = new Schema(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    // Adding these to the model to store contact info at the time of order
    email: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true
    },
    items: [
      {
        product: {
          type: Schema.Types.ObjectId,
          ref: "Product",
          required: true
        },
        product_name: { // Optional: Good to store the name in case the product is deleted later
          type: String 
        },
        price: {
          type: Number,
          required: true
        },
        quantity: {
          type: Number,
          required: true,
          default: 1
        }
      }
    ],
    total: {
      type: Number,
      required: true
    },
    shipAddress: {
      type: String,
      required: true
    },
    payment: {
      type: String,
      enum: ["pending", "paid"],
      default: "pending"
    },
    status: {
      type: String,
      enum: ["Ordered", "Packed", "Shipped", "Delivered"],
      default: "Ordered"
    }
  },
  { timestamps: true }
);

module.exports = model("Order", orderSchema);