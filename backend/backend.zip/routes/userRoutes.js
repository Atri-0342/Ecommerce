// const express = require("express");
// const router = express.Router();
// const {
//   register,
//   login,
//   refresh,
//   getAllUsers
// } = require("../controllers/userController");

// router.get("/", getAllUsers);
// router.post("/refresh", refresh);

// // Auth
// router.post("/register", register);
// router.post("/login", login);
const express = require("express");
const router = express.Router();
const {
  register, verifyRegisterOtp,
  login, verifyLoginOtp,
  resendOtp, getAllUsers, refresh
} = require("../controllers/userController");

router.post("/refresh", refresh);
router.get("/", getAllUsers);

// Auth
router.post("/register", register);
router.post("/verify-register-otp", verifyRegisterOtp);
router.post("/login", login);
router.post("/verify-login-otp", verifyLoginOtp);
router.post("/resend-otp", resendOtp);
module.exports = router;