// const express = require("express");
// const router = express.Router();
// const Message = require("../models/message");

// // Get history
// router.get("/:userId", async (req, res) => {
//   const messages = await Message.find({ userId: req.params.userId });
//   res.json(messages);
// });

// // Clear history
// router.delete("/clear/:userId", async (req, res) => {
//   await Message.deleteMany({ userId: req.params.userId });
//   res.send({ message: "Chat cleared" });
// });

// module.exports = router;
const express = require("express");
const router = express.Router();
const Message = require("../models/message"); // Ensure this matches your filename (message.js)

/**
 * @route   GET /messages/:userId
 * @desc    Fetch all previous chat history for a specific user
 */
router.get("/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId || userId === "undefined") {
      return res.status(400).json({ message: "Valid User ID is required" });
    }

    // .sort({ createdAt: 1 }) ensures messages appear in the correct order (oldest to newest)
    const messages = await Message.find({ userId }).sort({ createdAt: 1 });
    
    res.status(200).json(messages);
  } catch (err) {
    console.error("Error fetching chat history:", err.message);
    res.status(500).json({ message: "Server error while fetching messages" });
  }
});

/**
 * @route   DELETE /messages/clear/:userId
 * @desc    Wipe the entire chat history for a user (Reset Chat)
 */
router.delete("/clear/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId || userId === "undefined") {
      return res.status(400).json({ message: "Valid User ID is required" });
    }

    // Delete all documents matching this userId
    const result = await Message.deleteMany({ userId });

    res.status(200).json({ 
      message: "Chat history cleared successfully", 
      count: result.deletedCount 
    });
  } catch (err) {
    console.error("Error clearing chat history:", err.message);
    res.status(500).json({ message: "Server error while clearing chat" });
  }
});

module.exports = router;