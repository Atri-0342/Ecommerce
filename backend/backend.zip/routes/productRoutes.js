const express = require("express");
const router = express.Router();

const {
  createProduct,
  getAllProducts,
  getProduct,
  deleteProduct,
  updateProduct
}=require("../controllers/productController");

const upload=require("../middleware/upload"); 
router.post("/create",upload.single("image"),createProduct);
router.get("/",getAllProducts);
router.get("/:id",getProduct);
router.delete("/:id",deleteProduct);
router.put("/:id",upload.single("image"),updateProduct);

module.exports=router;