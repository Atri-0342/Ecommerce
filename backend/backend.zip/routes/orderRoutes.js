const express = require("express");
const router = express.Router();
const { 
  createOrder, 
  getAllOrders, 
  getOrdersByUser, 
  getOrder, 
  deleteOrder, 
  updateOrderStatus 
} = require("../controllers/orderController");

router.post("/create", createOrder);
router.get("/all", getAllOrders); // Change "/" to "/all" to match Admin.jsx
router.get("/user/:userId", getOrdersByUser);
router.get("/:id", getOrder);
router.put("/status/:id", updateOrderStatus); // Ensure this is present
router.delete("/:id", deleteOrder);

module.exports = router;