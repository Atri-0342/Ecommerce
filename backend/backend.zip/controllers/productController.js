const Product = require("../models/products");

exports.createProduct = async (req, res) => {
  try {
    let { product_name, price, description, stock } = req.body;

    if (!product_name || price == null || !description || stock == null) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : "";

    const product = await Product.create({
      product_name,
      price,
      description,
      stock,
      image: imageUrl,
    });

    return res.status(201).json({message: "Product created successfully",});
  } 
  catch (err) {
    return res.status(500).json({ message: "Internal server Issue" });
  }
};

// Get all products
exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 });
    return res.status(201).json({ count: products.length, products });
  } catch (err) {
    console.error("Get all products error:", err);
    return res.status(500).json({ message: "Internal Server Issue" });
  }
};

// Get product by Id
exports.getProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) return res.status(404).json({ message: "No Product Found" });

    return res.status(201).json(product);
  }
  catch (err) {
    return res.status(500).json({ message: "Internal Server Issue" });
  }
};

// Delete Product
exports.deleteProduct = async (req, res) => {
  try {
    const { id }= req.params;
    const deleted = await Product.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ message: "No Product Found" });

    return res.status(201).json({ message: "Product Successfully Deleted" });
  }
  catch (err) {
    return res.status(500).json({ message: "Internal Server Issue" });
  }
};

// Update Product
exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;

    if (req.file) {
      req.body.image = `/uploads/${req.file.filename}`;
    }

    const updated = await Product.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!updated) return res.status(404).json({ message: "No Product Found" });

    return res.status(201).json({message: "Product Successfully Updated",});
  }
  catch (err) {
    return res.status(500).json({ message: "Internal Server Issue" });
  }
};