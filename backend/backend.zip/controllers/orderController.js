const Order = require("../models/orders");
const Product = require("../models/products");
const mongoose = require("mongoose");
const nodemailer = require("nodemailer");

// --- HELPER: Universal Email Sender ---
const sendOrderEmail = async (to, subject, userName, bodyContent) => {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: '"MyShop Support" <no-reply@myshop.com>',
      to: to,
      subject: subject,
      html: `
        <div style="font-family: sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 12px; max-width: 600px;">
          <h2 style="color: #0d6efd;">Order Notification</h2>
          <p>Hi <strong>${userName}</strong>,</p>
          ${bodyContent}
          <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;" />
          <p style="font-size: 12px; color: #777;">This is an automated message. Please do not reply directly to this email.</p>
        </div>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log(`Email successfully sent to: ${to}`);
  } catch (error) {
    console.error("Nodemailer Error:", error);
  }
};

// --- HELPER: SMS Notification Placeholder ---
const sendSMSNotification = async (phone, message) => {
  try {
    // Logic for Twilio or other SMS gateways goes here
    console.log(`[SMS Simulation] To ${phone}: ${message}`);
  } catch (error) {
    console.error("SMS Error:", error);
  }
};

// 1. Create Order (With Stock Reduction & Initial Receipt)
exports.createOrder = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { 
      user, 
      items, 
      total, 
      shipAddress, 
      payment, 
      userEmail, 
      userName, 
      userPhone 
    } = req.body;

    if (!items || items.length === 0) throw new Error("No items in order");

    // Stock Management Logic
    for (const item of items) {
      const product = await Product.findById(item.product).session(session);
      if (!product) throw new Error(`Product ${item.product} not found`);
      if (product.stock < item.quantity) {
        throw new Error(`Insufficient stock for ${product.product_name}`);
      }
      product.stock -= item.quantity;
      await product.save({ session });
    }

    // Save Order (Including direct contact info for persistence)
    const newOrder = new Order({
      user,
      email: userEmail,
      phone: userPhone,
      items,
      total,
      shipAddress,
      payment,
      status: "Ordered"
    });

    await newOrder.save({ session });
    await session.commitTransaction();
    session.endSession();

    // Trigger Notifications
    const emailBody = `
      <p>Your order <strong>#${newOrder._id.toString().slice(-6).toUpperCase()}</strong> has been placed successfully!</p>
      <p><strong>Amount Paid:</strong> ₹${total}</p>
      <p><strong>Shipping to:</strong> ${shipAddress}</p>
      <p>We are currently packing your items and will notify you once they ship.</p>
    `;
    
    if (userEmail) sendOrderEmail(userEmail, "Order Confirmed!", userName, emailBody);
    if (userPhone) sendSMSNotification(userPhone, `Order confirmed! Total: ₹${total}. ID: ${newOrder._id.toString().slice(-6).toUpperCase()}`);

    res.status(201).json({ 
      success: true, 
      message: "Order placed successfully!", 
      order: newOrder 
    });

  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    res.status(400).json({ success: false, message: error.message });
  }
};

// 2. Get All Orders (Admin View)
exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("user", "name email phone") 
      .populate("items.product", "product_name image price")
      .sort({ createdAt: -1 });

    res.status(200).json({ count: orders.length, orders });
  } catch (err) {
    res.status(500).json({ message: "Internal server error", error: err.message });
  }
};

// 3. Update Order Status (Triggers Update Emails)
exports.updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowedStatuses = ["Ordered", "Packed", "Shipped", "Delivered"];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status value" });
    }

    const updatedOrder = await Order.findByIdAndUpdate(
      id,
      { status },
      { new: true }
    ).populate("user", "name");

    if (!updatedOrder) return res.status(404).json({ message: "Order not found" });

    // Send Status Update Email
    const emailBody = `
      <p>Great news! Your order status has been updated to: <strong style="color: #0d6efd;">${status}</strong></p>
      <p>You can track your order live on our website in the 'My Purchases' section.</p>
    `;
    
    // updatedOrder.email comes from our schema's persistent email field
    sendOrderEmail(updatedOrder.email, `Order Status: ${status}`, updatedOrder.user?.name || "Customer", emailBody);

    res.status(200).json({ success: true, message: `Status updated to ${status}`, order: updatedOrder });
  } catch (error) {
    res.status(500).json({ message: "Error updating status", error: error.message });
  }
};

// 4. Get Orders for Specific User (History)
exports.getOrdersByUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const orders = await Order.find({ user: userId })
      .populate("items.product", "product_name image")
      .sort({ createdAt: -1 });

    res.status(200).json({ count: orders.length, orders });
  } catch (err) {
    res.status(500).json({ message: "Internal server error" });
  }
};

// 5. Get Single Order Details
exports.getOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate("user", "name email phone address")
      .populate("items.product");

    if (!order) return res.status(404).json({ message: "Order not found" });
    res.status(200).json(order);
  } catch (err) {
    res.status(500).json({ message: "Internal server error" });
  }
};

// 6. Delete/Cancel Order
exports.deleteOrder = async (req, res) => {
  try {
    const deleted = await Order.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Order not found" });
    res.status(200).json({ success: true, message: "Order removed from system" });
  } catch (err) {
    res.status(500).json({ message: "Internal server error" });
  }
};