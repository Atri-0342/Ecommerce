// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");
// const User = require("../models/users");
// const { generateAccessToken, generateRefreshToken } = require("../utils/token");

// // 🔐 REGISTER (Direct - No OTP)
// exports.register = async (req, res) => {
//   try {
//     const { name, email, phone, address, password } = req.body;

//     if (!name || !email || !phone || !address || !password) {
//       return res.status(400).json({ message: "All fields are required" });
//     }

//     const existingUser = await User.findOne({ $or: [{ email }, { phone }] });
//     if (existingUser) {
//       return res.status(400).json({ message: "Email or phone already exists" });
//     }

//     const hashedPassword = await bcrypt.hash(String(password), 10);

//     await User.create({
//       name,
//       email,
//       phone,
//       address,
//       password: hashedPassword,
//     });

//     return res.status(201).json({ message: "Registration successful!" });
//   } catch (err) {
//     return res.status(500).json({ message: err.message });
//   }
// };

// // 🔐 LOGIN (Direct - No OTP)
// exports.login = async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password)
//       return res.status(400).json({ message: "Email and password required" });

//     const user = await User.findOne({ email });
//     if (!user) return res.status(400).json({ message: "User not found" });

//     const matched = await bcrypt.compare(password, user.password);
//     if (!matched) return res.status(400).json({ message: "Invalid credentials" });

//     // Generate tokens
//     const accessToken = generateAccessToken(user);
//     const refreshToken = generateRefreshToken(user);

//     // Set HTTP-Only Cookie
//     res.cookie("refreshToken", refreshToken, {
//       httpOnly: true,
//       secure: false, // Set to true in production (HTTPS)
//       sameSite: "lax",
//       maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
//       path: "/",
//     });

//     // Strip sensitive fields
//     const { password: p, ...safeUser } = user._doc;

//     return res.json({
//       message: "Login successful",
//       accessToken,
//       user: safeUser
//     });
//   } catch (err) {
//     return res.status(500).json({ message: "Internal Server Error" });
//   }
// };

// // 🔁 REFRESH TOKEN (For App.jsx initial load)
// exports.refresh = async (req, res) => {
//   const token = req.cookies.refreshToken;
//   if (!token) return res.status(401).json({ message: "No refresh token" });

//   try {
//     const decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
    
//     const user = await User.findById(decoded.id).select("-password");
//     if (!user) return res.status(401).json({ message: "User not found" });

//     const newAccessToken = jwt.sign(
//       { id: user._id },
//       process.env.ACCESS_TOKEN_SECRET,
//       { expiresIn: "15m" }
//     );

//     return res.json({ accessToken: newAccessToken, user });
//   } catch (err) {
//     return res.status(401).json({ message: "Invalid refresh token" });
//   }
// };

// // 👥 GET ALL USERS
// exports.getAllUsers = async (req, res) => {
//   try {
//     const users = await User.find().select("-password");
//     return res.status(200).json({ count: users.length, users });
//   } catch (err) {
//     return res.status(500).json({ message: "Internal Server Issue" });
//   }
// };
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer"); // 1. Added Nodemailer
const User = require("../models/users");
const { generateAccessToken, generateRefreshToken } = require("../utils/token");

// 📧 Helper Function to send emails
const sendEmail = async (email, otp, subject) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS, // Use App Password here
    },
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: subject,
    html: `<h3>Your Verification Code:</h3><h1>${otp}</h1><p>Expires in 5 minutes.</p>`,
  };

  return transporter.sendMail(mailOptions);
};

// 🔐 REGISTER (Send OTP via Email)
exports.register = async (req, res) => {
  try {
    const { name, email, phone, address, password } = req.body;

    if (!name || !email || !phone || !address || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const existingUser = await User.findOne({ $or: [{ email }, { phone }] });
    if (existingUser) {
      return res.status(400).json({ message: "Email or phone already exists" });
    }

    const hashedPassword = await bcrypt.hash(String(password), 10);
    const otp = Math.floor(100000 + Math.random() * 900000);

    await User.create({
      name,
      email,
      phone,
      address,
      password: hashedPassword,
      otp,
      otpExpire: Date.now() + 5 * 60 * 1000,
      isVerified: false
    });

    // 🔥 Send the actual email
    await sendEmail(email, otp, "Verify Your Registration");

    console.log("Register OTP sent to email:", otp);

    return res.status(200).json({
      message: "OTP sent to your email!",
      email
    });

  } catch (err) {
    console.log("🔥 REGISTER ERROR:", err);
    return res.status(500).json({ message: err.message });
  }
};

// 🔐 LOGIN (Send OTP via Email)
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ message: "Email and password required" });

    const user = await User.findOne({ email });

    if (!user)
      return res.status(400).json({ message: "User not found" });

    const matched = await bcrypt.compare(password, user.password);

    if (!matched)
      return res.status(400).json({ message: "Invalid credentials" });

    if (!user.isVerified)
      return res.status(400).json({ message: "Please verify your account first" });

    const otp = Math.floor(100000 + Math.random() * 900000);

    user.otp = otp;
    user.otpExpire = Date.now() + 5 * 60 * 1000;
    await user.save();

    // 🔥 Send the actual email
    await sendEmail(email, otp, "Login Verification Code");

    console.log("Login OTP sent to email:", otp);

    return res.json({
      message: "OTP sent for login",
      email
    });

  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// 🔐 VERIFY REGISTER OTP
exports.verifyRegisterOtp = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(400).json({ message: "User not found" });
    if (user.otp !== Number(otp)) return res.status(400).json({ message: "Invalid OTP" });

    if (user.otpExpire < Date.now()) {
      user.otp = null;
      user.otpExpire = null;
      await user.save();
      return res.status(400).json({ message: "OTP expired" });
    }

    user.isVerified = true;
    user.otp = null;
    user.otpExpire = null;
    await user.save();

    return res.json({ message: "Registration successful" });
  } catch (err) {
    return res.status(500).json({ message: "Error verifying OTP" });
  }
};

// 🔐 VERIFY LOGIN OTP
exports.verifyLoginOtp = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(400).json({ message: "User not found" });
    if (user.otp !== Number(otp)) return res.status(400).json({ message: "Invalid OTP" });

    if (user.otpExpire < Date.now()) {
      user.otp = null;
      user.otpExpire = null;
      await user.save();
      return res.status(400).json({ message: "OTP expired" });
    }

    user.otp = null;
    user.otpExpire = null;
    await user.save();

    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);

    res.cookie("refreshToken", refreshToken, {
      httpOnly: true,
      secure: false, // true in production
      sameSite: "lax",
      maxAge: 30 * 60 * 1000,
      path: "/",
    });

    const { password, otp: o, otpExpire, ...safeUser } = user._doc;

    return res.json({
      message: "Login successful",
      accessToken,
      user: safeUser
    });
  } catch (err) {
    return res.status(500).json({ message: "Error verifying OTP" });
  }
};

// 🔁 REFRESH TOKEN
exports.refresh = (req, res) => {
  const token = req.cookies.refreshToken;
  if (!token) return res.status(401).json({ message: "No refresh token" });

  jwt.verify(token, process.env.REFRESH_TOKEN_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: "Invalid refresh token" });
    const newAccessToken = jwt.sign(
      { id: decoded.id },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "15m" }
    );
    return res.json({ accessToken: newAccessToken });
  });
};
// 🔁 RESEND OTP (For both Login and Registration)
exports.resendOtp = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Generate new OTP
    const otp = Math.floor(100000 + Math.random() * 900000);
    
    // Update user record with new OTP and fresh expiration (5 mins)
    user.otp = otp;
    user.otpExpire = Date.now() + 5 * 60 * 1000;
    await user.save();

    // Send the actual email using your helper
    await sendEmail(email, otp, "Your New Verification Code");

    console.log(`Resend OTP (${otp}) sent to: ${email}`);

    return res.status(200).json({
      message: "A new OTP has been sent to your email!",
      email
    });

  } catch (err) {
    console.error("Resend OTP Error:", err);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};
// 👥 GET ALL USERS
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password -otp -otpExpire");
    return res.status(200).json({ count: users.length, users });
  } catch (err) {
    return res.status(500).json({ message: "Internal Server Issue" });
  }
};