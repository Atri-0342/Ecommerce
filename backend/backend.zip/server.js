
// require("dotenv").config();
// const path = require("path");
// const express = require("express");
// const cors = require("cors");
// const cookieParser = require("cookie-parser");

// const connectDB = require("./config/db");
// connectDB();

// const app = express();

// // ✅ CORS CONFIG (IMPORTANT FOR FRONTEND + COOKIES)
// // app.use(
// //   cors({
// //     origin: "http://localhost:5174",
// //     credentials: true,
// //     methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
// //     allowedHeaders: ["Content-Type", "Authorization"],
// //   })
// // );
// app.use(cors({
//   origin: true,          // 🔥 IMPORTANT (auto allows 5173/5174)
//   credentials: true
// }));
// // ✅ BODY PARSER
// app.use(express.json({ limit: "2mb" }));
// app.use(express.urlencoded({ extended: true }));

// // ✅ COOKIE PARSER
// app.use(cookieParser());

// // ✅ STATIC FILES (UPLOADS)
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// // ✅ ROUTES
// const userRoutes = require("./routes/userRoutes");
// const productRoutes = require("./routes/productRoutes");
// const orderRoutes = require("./routes/orderRoutes");

// // 🔥 IMPORTANT: MATCH FRONTEND API
// app.use("/users", userRoutes);
// app.use("/products", productRoutes);
// app.use("/orders", orderRoutes);

// // ✅ HEALTH CHECK
// app.get("/", (req, res) => {
//   res.send("Server is running 🚀");
// });

// // ✅ PORT
// const PORT = process.env.PORT || 5000;

// // ✅ START SERVER
// app.listen(PORT, () => {
//   console.log(`Server running on http://localhost:${PORT}`);
// });
// require("dotenv").config();
// const path = require("path");
// const express = require("express");
// const cors = require("cors");
// const cookieParser = require("cookie-parser");
// const http = require("http"); // 🔥 Added for Socket.io
// const { Server } = require("socket.io"); // 🔥 Added for Socket.io
// const Groq = require("groq-sdk"); // 🔥 Added for AI
// const messageRoutes = require("./routes/messageRoutes");
// const connectDB = require("./config/db");
// connectDB();

// // ✅ Initialize Groq
// const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// // ✅ Models
// const Message = require("./models/messages"); // Ensure this file exists in models

// const app = express();

// // ✅ Create HTTP Server (Required for Socket.io)
// const server = http.createServer(app);

// // ✅ Socket.io Setup
// const io = new Server(server, {
//   cors: {
//     origin: true,
//     credentials: true,
//   },
// });

// // ✅ Middleware
// app.use(cors({
//   origin: true,
//   credentials: true
// }));
// app.use(express.json({ limit: "2mb" }));
// app.use(express.urlencoded({ extended: true }));
// app.use(cookieParser());

// // ✅ Static Files
// app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// // ================= 🔥 CHATBOT SOCKET LOGIC =================
// io.on("connection", (socket) => {
//   console.log("User connected:", socket.id);

//   // 1. Handle Welcome Message
//   socket.on("join_chat", async ({ userId }) => {
//     if (!userId) return;
//     try {
   
//       const existingMessages = await Message.findOne({ userId });
      
//       // ✨ Only create a welcome message if the chat is brand new/empty
//       if (!existingMessages) {
//         const welcomeMsg = await Message.create({
//           userId,
//           sender: "bot",
//           text: "Welcome to MyShop! 🛍️ How can I help you today?"
//         });
//         socket.emit("receive_message", welcomeMsg);
//       }}
//      catch (err) {
//       console.error("Welcome Msg Error:", err);
//     }
//   });

//   // 2. Handle Messaging
//   socket.on("send_message", async (data) => {
//     try {
//       const { text, userId } = data;

//       // Save User Message
//       const userMsg = await Message.create({ userId, sender: "user", text });
//       socket.emit("receive_message", userMsg);

//       // Get Groq AI Response
//       const completion = await groq.chat.completions.create({
//         messages: [
//           { role: "system", content: "You are a helpful assistant for an e-commerce store called MyShop." },
//           { role: "user", content: text }
//         ],
//         model: "llama-3.3-70b-versatile",
//       });

//       const botReply = completion.choices[0].message.content;

//       // Save & Send Bot Message
//       const botMsg = await Message.create({ userId, sender: "bot", text: botReply });
//       socket.emit("receive_message", botMsg);

//     } catch (err) {
//       console.error("Chat Error:", err);
//       socket.emit("receive_message", { sender: "bot", text: "I'm having trouble thinking right now. 😅" });
//     }
//   });

//   socket.on("disconnect", () => {
//     console.log("User disconnected:", socket.id);
//   });
// });
// // ===========================================================

// // ✅ Routes
// const userRoutes = require("./routes/userRoutes");
// const productRoutes = require("./routes/productRoutes");
// const orderRoutes = require("./routes/orderRoutes");
// const messageRoutes = require("./routes/messageRoutes"); // 🔥 Added for clear chat

// app.use("/users", userRoutes);
// app.use("/products", productRoutes);
// app.use("/orders", orderRoutes);
// app.use("/messages", messageRoutes); // 🔥 Added

// // ✅ Health Check
// app.get("/", (req, res) => {
//   res.send("Server is running with Chatbot 🚀");
// });

// const PORT = process.env.PORT || 5000;

// // ✅ IMPORTANT: Change app.listen to server.listen
// server.listen(PORT, () => {
//   console.log(`Server running on http://localhost:${PORT}`);
// });
require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const http = require("http"); 
const { Server } = require("socket.io"); 
const Groq = require("groq-sdk"); 

// ✅ 1. IMPORT ALL ROUTES AT THE TOP (Only once!)
const userRoutes = require("./routes/userRoutes");
const productRoutes = require("./routes/productRoutes");
const orderRoutes = require("./routes/orderRoutes");
const messageRoutes = require("./routes/messageRoutes"); 

const connectDB = require("./config/db");
connectDB();

// ✅ Initialize AI
const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// ✅ Models
const Message = require("./models/message"); 

const app = express();
const server = http.createServer(app);

// ✅ Socket.io Setup
const io = new Server(server, {
  cors: {
    origin: true,
    credentials: true,
  },
});

// ✅ Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ✅ Static Files
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ✅ 2. REGISTER ROUTES
app.use("/users", userRoutes);
app.use("/products", productRoutes);
app.use("/orders", orderRoutes);
app.use("/messages", messageRoutes); 

// ================= 🔥 CHATBOT SOCKET LOGIC =================
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join_chat", async ({ userId }) => {
    if (!userId) return;
    try {
      const existingMessages = await Message.findOne({ userId });
      if (!existingMessages) {
        const welcomeMsg = await Message.create({
          userId,
          sender: "bot",
          text: "Welcome to MyShop! 🛍️ How can I help you today?"
        });
        socket.emit("receive_message", welcomeMsg);
      }
    } catch (err) {
      console.error("Welcome Msg Error:", err);
    }
  });

  socket.on("send_message", async (data) => {
    try {
      const { text, userId } = data;
      const userMsg = await Message.create({ userId, sender: "user", text });
      socket.emit("receive_message", userMsg);

      const completion = await groq.chat.completions.create({
        messages: [
          { role: "system", content: "You are a helpful assistant for MyShop." },
          { role: "user", content: text }
        ],
        model: "llama-3.3-70b-versatile",
      });

      const botMsg = await Message.create({ 
        userId, 
        sender: "bot", 
        text: completion.choices[0].message.content 
      });
      socket.emit("receive_message", botMsg);

    } catch (err) {
      console.error("Chat Error:", err);
      socket.emit("receive_message", { sender: "bot", text: "I'm having trouble thinking right now. 😅" });
    }
  });

  socket.on("disconnect", () => console.log("User disconnected:", socket.id));
});

// ✅ Health Check
app.get("/", (req, res) => res.send("Server is running with Chatbot 🚀"));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});