// // import { useEffect, useState } from "react";
// // import { Routes, Route, Navigate, Outlet } from "react-router-dom";
// // import { useSelector, useDispatch } from "react-redux";
// // import axios from "axios";
// // import { setAccessToken, setUser } from "./store/authSlice";

// // // Pages
// // import Admin from "./pages/Admin";
// // import BookingPage from "./pages/BookingPage";
// // import CartPage from "./pages/CartPage";
// // import Dashboard from "./pages/Dashboard";
// // import Login from "./pages/Login";
// // import OrdersPage from "./pages/OrdersPage";
// // import Register from "./pages/Register";
// // import Search from "./pages/Search";
// // import PaymentPage from "./pages/PaymentPage"; // Import PaymentPage

// // import VerifyRegisterOtp from "./pages/VerifyRegisterOtp";
// // import VerifyLoginOtp from "./pages/VerifyLoginOtp";

// // function App() {
// //   const dispatch = useDispatch();
// //   const API = import.meta.env.VITE_API_URL;
// //   const { accessToken } = useSelector((state) => state.auth);
// //   const [loading, setLoading] = useState(true);

// //   // --- AXIOS GLOBAL INTERCEPTOR ---
// //   // This automatically adds the Bearer token to every request if it exists
// //   useEffect(() => {
// //     const interceptor = axios.interceptors.request.use(
// //       (config) => {
// //         if (accessToken) {
// //           config.headers.Authorization = `Bearer ${accessToken}`;
// //         }
// //         return config;
// //       },
// //       (error) => Promise.reject(error)
// //     );

// //     return () => axios.interceptors.request.eject(interceptor);
// //   }, [accessToken]);

// //   // --- REFRESH SESSION ON LOAD ---
// //   useEffect(() => {
// //     const refreshApp = async () => {
// //       try {
// //         const res = await axios.post(`${API}/users/refresh`, {}, { withCredentials: true });
        
// //         if (res.data.accessToken && res.data.user) {
// //           dispatch(setAccessToken(res.data.accessToken));
// //           dispatch(setUser(res.data.user));
// //         }
// //       } catch (err) {
// //         console.warn("No active session found.");
// //       } finally {
// //         setLoading(false);
// //       }
// //     };
// //     refreshApp();
// //   }, [dispatch, API]);

// //   if (loading) return (
// //     <div className="d-flex justify-content-center align-items-center vh-100">
// //       <div className="spinner-border text-primary" role="status"></div>
// //     </div>
// //   );

// //   return (
// //     <Routes>
// //       {/* Public Routes */}
// //       <Route path="/login" element={<Login />} />
// //       <Route path="/register" element={<Register />} />
// //       <Route path="/search" element={<Search />} />

// //       {/* Protected Routes */}
// //       <Route element={<ProtectedRoute />}>
// //         <Route path="/" element={<Dashboard />} />
// //         <Route path="/dashboard" element={<Dashboard />} />
// //         <Route path="/booking/:id" element={<BookingPage />} />
// //         <Route path="/cart" element={<CartPage />} />
// //         <Route path="/orders" element={<OrdersPage />} />
// //         <Route path="/payment" element={<PaymentPage />} /> {/* Added Payment Route */}
// //         <Route path="/admin" element={<Admin />} />
// //       </Route>

// //       <Route path="*" element={<div className="p-5 text-center"><h3>404 Not Found</h3></div>} />
// //     </Routes>
// //   );
// // }

// // const ProtectedRoute = () => {
// //   const { accessToken } = useSelector((state) => state.auth);
// //   // Using replace to prevent the user from going back to the login page after logging in
// //   return accessToken ? <Outlet /> : <Navigate to="/login" replace />;
// // };

// // export default App;
// import { Routes, Route, Navigate } from "react-router-dom";
// import React, { useEffect } from "react";
// import { useSelector, useDispatch } from "react-redux";
// import axios from "axios";

// // ✅ Import Pages
// import Login from "./pages/Login";
// import Register from "./pages/Register";
// import Dashboard from "./pages/Dashboard";
// import Search from "./pages/Search"; 
// import Admin from "./pages/Admin";
// import BookingPage from "./pages/BookingPage";
// import PaymentPage from "./pages/PaymentPage";
// import CartPage from "./pages/CartPage";
// import OrdersPage from "./pages/OrdersPage";

// // ✅ Import New OTP Pages
// import VerifyRegisterOtp from "./pages/VerifyRegisterOtp";
// import VerifyLoginOtp from "./pages/VerifyLoginOtp";

// // ✅ Store Actions
// import { setAccessToken, setUser } from "./store/authSlice";

// function App() {
//   const API = import.meta.env.VITE_API_URL;
//   const dispatch = useDispatch();

//   // 🔁 Maintain session by refreshing token on app load
//   useEffect(() => {
//     const tryRefresh = async () => {
//       try {
//         const res = await axios.post(
//           `${API}/users/refresh`,
//           {},
//           { withCredentials: true }
//         );

//         dispatch(setAccessToken(res.data.accessToken));
//         if (res.data.user) {
//           dispatch(setUser(res.data.user));
//         }
//       } catch (err) {
//         console.log("No active session found.");
//       }
//     };

//     tryRefresh();
//   }, [dispatch, API]);


//   // ✋ Stop the app from rendering routes until we know if the user is logged in
//   if (isRefreshing) {
//     return (
//       <div className="vh-100 d-flex justify-content-center align-items-center">
//         <div className="spinner-border text-primary" role="status"></div>
//       </div>
//     );
//   }
//   return (
//     <Routes>
//       {/* 🔐 AUTH ROUTES */}
//       <Route
//         path="/login"
//         element={
//           <ProtectedRoute1>
//             <Login />
//           </ProtectedRoute1>
//         }
//       />
//       <Route path="/register" element={<Register />} />

//       {/* 🔐 OTP ROUTES (2-Way Auth) */}
//       {/* These should not be protected by tokens yet, as the user isn't fully logged in */}
//       <Route path="/verify-register" element={<VerifyRegisterOtp />} />
//       <Route path="/verify-login" element={<VerifyLoginOtp />} />

//       {/* 🔒 PROTECTED USER ROUTES (Require Access Token) */}
//       <Route
//         path="/"
//         element={
//           <ProtectedRoute2>
//             <Dashboard />
//           </ProtectedRoute2>
//         }
//       />

//       <Route
//         path="/search"
//         element={
//           <ProtectedRoute2>
//             <Search />
//           </ProtectedRoute2>
//         }
//       />

//       <Route
//         path="/product/:id"
//         element={
//           <ProtectedRoute2>
//             <BookingPage />
//           </ProtectedRoute2>
//         }
//       />

//       <Route
//         path="/payment"
//         element={
//           <ProtectedRoute2>
//             <PaymentPage />
//           </ProtectedRoute2>
//         }
//       />

//       <Route
//         path="/cart"
//         element={
//           <ProtectedRoute2>
//             <CartPage />
//           </ProtectedRoute2>
//         }
//       />

//       <Route
//         path="/orders"
//         element={
//           <ProtectedRoute2>
//             <OrdersPage />
//           </ProtectedRoute2>
//         }
//       />

//       {/* 🛡️ ADMIN PANEL */}
//       <Route path="/admin" element={<Admin />} />

//       {/* 🔄 FALLBACK */}
//       <Route path="*" element={<Navigate to="/" replace />} />
//     </Routes>
//   );
// }

// /**
//  * 🔐 ProtectedRoute1:
//  * Logic: If user already has a token, they are fully logged in.
//  * Redirect them away from login/register/otp pages to home.
//  */
// const ProtectedRoute1 = ({ children }) => {
//   const token = useSelector((s) => s.auth.accessToken);
//   if (token) return <Navigate to="/" replace />;
//   return children;
// };

// /**
//  * 🔒 ProtectedRoute2:
//  * Logic: Access only for fully verified users with an access token.
//  */
// const ProtectedRoute2 = ({ children }) => {
//   const token = useSelector((s) => s.auth.accessToken);
//   if (!token) return <Navigate to="/login" replace />;
//   return children;
// };

// export default App;
import { Routes, Route, Navigate } from "react-router-dom";
import React, { useEffect, useState } from "react"; // ✅ Added useState
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";

// ✅ Import Pages
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Search from "./pages/Search"; 
import Admin from "./pages/Admin";
import BookingPage from "./pages/BookingPage";
import PaymentPage from "./pages/PaymentPage";
import CartPage from "./pages/CartPage";
import OrdersPage from "./pages/OrdersPage";

// ✅ Import OTP Pages
import VerifyRegisterOtp from "./pages/VerifyRegisterOtp";
import VerifyLoginOtp from "./pages/VerifyLoginOtp";

// ✅ Store Actions
import { setAccessToken, setUser } from "./store/authSlice";

function App() {
  const API = import.meta.env.VITE_API_URL;
  const dispatch = useDispatch();

  // ✅ State to track the background session check
  const [isRefreshing, setIsRefreshing] = useState(true);

  // 🔁 Maintain session by refreshing token on app load
  useEffect(() => {
    const tryRefresh = async () => {
      try {
        const res = await axios.post(
          `${API}/users/refresh`,
          {},
          { withCredentials: true }
        );

        // Populate Redux with fresh session data
        dispatch(setAccessToken(res.data.accessToken));
        if (res.data.user) {
          dispatch(setUser(res.data.user));
        }
      } catch (err) {
        console.log("No active session found.");
      } finally {
        // ✅ Stop the loading spinner regardless of success or failure
        setIsRefreshing(false);
      }
    };

    tryRefresh();
  }, [dispatch, API]);

  // ✋ Guard: Don't render routes until the session check is complete
  if (isRefreshing) {
    return (
      <div className="vh-100 d-flex justify-content-center align-items-center bg-light">
        <div className="text-center">
          <div className="spinner-border text-primary mb-3" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="text-muted fw-bold">Connecting to server...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* 🔐 AUTH ROUTES */}
      <Route
        path="/login"
        element={
          <ProtectedRoute1>
            <Login />
          </ProtectedRoute1>
        }
      />
      <Route path="/register" element={<Register />} />
      <Route path="/verify-register" element={<VerifyRegisterOtp />} />
      <Route path="/verify-login" element={<VerifyLoginOtp />} />

      {/* 🔒 PROTECTED USER ROUTES */}
      <Route
        path="/"
        element={
          <ProtectedRoute2>
            <Dashboard />
          </ProtectedRoute2>
        }
      />

      <Route
        path="/search"
        element={
          <ProtectedRoute2>
            <Search />
          </ProtectedRoute2>
        }
      />

      <Route
        path="/product/:id"
        element={
          <ProtectedRoute2>
            <BookingPage />
          </ProtectedRoute2>
        }
      />

      <Route
        path="/payment"
        element={
          <ProtectedRoute2>
            <PaymentPage />
          </ProtectedRoute2>
        }
      />

      <Route
        path="/cart"
        element={
          <ProtectedRoute2>
            <CartPage />
          </ProtectedRoute2>
        }
      />

      <Route
        path="/orders"
        element={
          <ProtectedRoute2>
            <OrdersPage />
          </ProtectedRoute2>
        }
      />

      {/* 🛡️ ADMIN PANEL */}
      <Route path="/admin" element={<Admin />} />

      {/* 🔄 FALLBACK */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

/**
 * 🔐 ProtectedRoute1:
 * Logic: If user is already logged in, redirect them away from Login/Register.
 */
const ProtectedRoute1 = ({ children }) => {
  const token = useSelector((s) => s.auth.accessToken);
  if (token) return <Navigate to="/" replace />;
  return children;
};

/**
 * 🔒 ProtectedRoute2:
 * Logic: Only allow access if a valid access token exists in Redux.
 */
const ProtectedRoute2 = ({ children }) => {
  const token = useSelector((s) => s.auth.accessToken);
  if (!token) return <Navigate to="/login" replace />;
  return children;
};

export default App;