import { Navbar, Nav, Container, Button, Offcanvas, Form, InputGroup } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logout } from "../store/authSlice";
import { useState } from "react";
import React from "react";

const Navigation = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [showSidebar, setShowSidebar] = useState(false);
  const [search, setSearch] = useState("");

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  const goToSearch = () => {
    if (search.trim()) {
      navigate("/search", { state: { query: search } });
      setShowSidebar(false);
    }
  };

  return (
    <>
      <Navbar bg="white" expand="lg" className="shadow-sm py-3 sticky-top">
        <Container>
          <Navbar.Brand 
            role="button" 
            onClick={() => navigate("/")} 
            className="fw-bold fs-3 text-primary"
            style={{ letterSpacing: "-1px" }}
          >
           YuKTI<span className="text-dark"></span>
          </Navbar.Brand>

          <div className="d-flex align-items-center gap-2">
            <Nav className="d-none d-lg-flex gap-3 me-3">
              <Nav.Link onClick={() => navigate("/")} className="fw-semibold text-dark">Home</Nav.Link>
              <Nav.Link onClick={() => navigate("/cart")} className="fw-semibold text-dark">Cart</Nav.Link>
              <Nav.Link onClick={() => navigate("/orders")} className="fw-semibold text-dark">Orders</Nav.Link>
              <Nav.Link onClick={() => navigate("/profile")} className="fw-semibold text-dark">Profile</Nav.Link>
            </Nav>

            <Button 
               variant="danger" 
               className="d-none d-lg-block rounded-pill px-4 fw-bold shadow-sm"
               onClick={handleLogout}
            >
              Logout
            </Button>

            <Button
              variant="light"
              className="border-0 d-lg-none fs-4"
              onClick={() => setShowSidebar(true)}
            >
              ☰
            </Button>
          </div>
        </Container>
      </Navbar>

      <Offcanvas show={showSidebar} onHide={() => setShowSidebar(false)} placement="end">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title className="fw-bold">Explore MyShop</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <div className="mb-4">
            <InputGroup className="bg-light rounded p-1 border">
              <Form.Control
                placeholder="Search..."
                className="border-0 bg-transparent shadow-none"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && goToSearch()}
              />
              <Button variant="primary" className="rounded" onClick={goToSearch}>🔍</Button>
            </InputGroup>
          </div>

          <div className="d-grid gap-2">
            <Button variant="light" className="text-start py-3 border-0" onClick={() => navigate("/")}>🏠 Home</Button>
            <Button variant="light" className="text-start py-3 border-0" onClick={() => navigate("/cart")}>🛒 Cart</Button>
            <Button variant="light" className="text-start py-3 border-0" onClick={() => navigate("/orders")}>📦 Orders</Button>
            <Button variant="light" className="text-start py-3 border-0" onClick={() => navigate("/profile")}>👤 Profile</Button>
            <hr />
            <Button variant="danger" className="py-3 fw-bold shadow-sm" onClick={handleLogout}>Logout</Button>
          </div>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default Navigation;