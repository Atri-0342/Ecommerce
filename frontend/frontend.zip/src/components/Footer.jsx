import { Container, Row, Col, InputGroup, Form, Button } from "react-bootstrap";

const Footer = () => {
  return (
    <footer className="modern-footer">
      <Container className="pt-5 pb-4">
        <Row className="gy-4">
          <Col lg={4} md={12}>
            <h4 className="fw-bold text-white mb-4">MyShop<span className="text-primary">.</span></h4>
            <p className="text-white-50 mb-4 pe-lg-5">
              Elevating your online shopping experience with quality products and seamless service. 
              Grounded in excellence, focused on you.
            </p>
            <div className="d-flex gap-3">
              <div className="social-icon">fb</div>
              <div className="social-icon">tw</div>
              <div className="social-icon">ig</div>
            </div>
          </Col>
          
          <Col xs={6} lg={2} md={4}>
            <h6 className="fw-bold text-white mb-4">Quick Links</h6>
            <ul className="list-unstyled footer-links text-white-50">
              <li>Home</li>
              <li>Categories</li>
              <li>Trending</li>
              <li>New Arrivals</li>
            </ul>
          </Col>

          <Col xs={6} lg={2} md={4}>
            <h6 className="fw-bold text-white mb-4">Support</h6>
            <ul className="list-unstyled footer-links text-white-50">
              <li>Help Center</li>
              <li>Returns</li>
              <li>Track Order</li>
              <li>Contact</li>
            </ul>
          </Col>

          <Col lg={4} md={4}>
            <h6 className="fw-bold text-white mb-4">Newsletter</h6>
            <p className="text-white-50 small">Get special offers and deals.</p>
            <InputGroup className="mt-3 overflow-hidden rounded-pill">
              <Form.Control placeholder="Email..." className="border-0 ps-3 bg-white text-black shadow-none" />
              <Button variant="primary" className="fw-bold">Join</Button>
            </InputGroup>
          </Col>
        </Row>
        <hr className="my-5 border-secondary opacity-25" />
        <div className="text-center text-white-50 small">
          © {new Date().getFullYear()} MyShop — All Rights Reserved.
        </div>
      </Container>
    </footer>
  );
};

export default Footer;