import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../store/authSlice";
import "./pages.css";

const BookingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const API = import.meta.env.VITE_API_URL;

  // Check login state
  const isLoggedIn = useSelector((state) => state.auth.accessToken);

  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [search, setSearch] = useState("");

  // Load product
  useEffect(() => {
    async function loadProduct() {
      try {
        const res = await axios.get(`${API}/products/${id}`);
        setProduct(res.data);
      } catch (err) {
        console.log(err);
      }
    }
    loadProduct();
  }, [id, API]);

  const handleAddToCart = () => {
    if (!isLoggedIn) return navigate("/login");

    let carts = JSON.parse(localStorage.getItem("cart")) || [];

    const existing = carts.find((item) => item._id === product._id);

    if (existing) {
      existing.qty += Number(qty);
    } else {
      carts.push({
        _id: product._id,
        product_name: product.product_name,
        price: product.price,
        qty: Number(qty),
        image: product.image,
      });
    }

    localStorage.setItem("cart", JSON.stringify(carts));

    alert("Added to cart!");
    navigate("/cart");
  };

  const handleOrder = () => {
    if (!isLoggedIn) return navigate("/login");

    navigate("/payment", {
      state: {
        cart: [
          {
            _id: product._id,
            product_name: product.product_name,
            price: product.price,
            qty: Number(qty),
            image: product.image
          }
        ],
        total: product.price * qty
      }
    });
  };

  if (!product) return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div className="spinner-border text-primary" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
    </div>
  );

  return (
    <>
      {/* --- NAVBAR --- */}
      <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-4 py-3 sticky-top">
        <div className="container-fluid">
          <h2 className="navbar-brand fw-bold mb-0 text-primary" 
              style={{ cursor: "pointer", fontSize: "1.5rem" }} 
              onClick={() => navigate("/")}>
            MyShop
          </h2>

          <div className="mx-auto d-none d-md-flex" style={{ width: "40%" }}>
            <div className="input-group">
              <input
                type="text"
                placeholder="Search products..."
                className="form-control border-end-0"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <button className="btn btn-outline-secondary border-start-0" type="button">
                🔍
              </button>
            </div>
          </div>

          <div className="d-flex gap-2">
            <button onClick={() => navigate("/")} className="btn btn-outline-dark border-0 fw-semibold">Home</button>
            <button onClick={() => navigate("/cart")} className="btn btn-outline-dark border-0 fw-semibold">Cart</button>
            <button onClick={() => navigate("/orders")} className="btn btn-outline-dark border-0 fw-semibold">Orders</button>
            <button
              className="btn btn-danger ms-2 px-3 fw-bold"
              onClick={() => {
                dispatch(logout());
                navigate("/login");
              }}
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      {/* --- PRODUCT DETAILS SECTION --- */}
      <div className="container py-5">
        <div className="card shadow-lg border-0 rounded-4 overflow-hidden">
          <div className="row g-0">
            
            {/* Image Column */}
            <div className="col-md-6 bg-white d-flex align-items-center justify-content-center p-5 border-end">
              <img
                src={product?.image ? `${API}${product.image}` : "/placeholder.jpg"}
                alt={product.product_name}
                className="img-fluid"
                style={{ maxHeight: "400px", objectFit: "contain" }}
              />
            </div>

            {/* Content Column */}
            <div className="col-md-6 p-4 p-lg-5 d-flex flex-column justify-content-center">
              <h1 className="display-6 fw-bold text-dark mb-2">{product.product_name}</h1>
              <h2 className="text-success fw-bold mb-4">₹ {product.price}</h2>
              
              <div className="mb-4">
                <h6 className="text-uppercase text-muted fw-bold">Description</h6>
                <p className="text-secondary" style={{ fontSize: "1.1rem", lineHeight: "1.6" }}>
                  {product.description}
                </p>
              </div>

              <div className="mb-4" style={{ maxWidth: "150px" }}>
                <label className="form-label fw-bold small">Quantity</label>
                <input
                  type="number"
                  min="1"
                  className="form-control form-control-lg text-center"
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                />
              </div>

              <div className="row g-3">
                <div className="col-sm-6">
                  <button className="btn btn-primary btn-lg w-100 fw-bold py-3 shadow-sm" onClick={handleAddToCart}>
                    Add to Cart
                  </button>
                </div>
                <div className="col-sm-6">
                  <button className="btn btn-success btn-lg w-100 fw-bold py-3 shadow-sm" onClick={handleOrder}>
                    Place Order
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
};

export default BookingPage;