import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import "./pages.css";

const Register = () => {
  const API = import.meta.env.VITE_API_URL;
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    password: "",
  });

  const onChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Direct registration call
      await axios.post(`${API}/users/register`, form);
      alert("Registration Successful! Please login.");
      navigate("/login");
    } catch (err) {
      console.error("Registration Error:", err);
      alert(err.response?.data?.message || "Registration failed. Please try again.");
    }
  };

  return (
    <div className="register-page">
      <div className="register-box">
        <h3 className="title">Create Account</h3>

        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Name:</label>
            <input type="text" name="name" value={form.name} onChange={onChange} required />
          </div>

          <div className="input-group">
            <label>Email:</label>
            <input type="email" name="email" value={form.email} onChange={onChange} required />
          </div>

          <div className="input-group">
            <label>Phone:</label>
            <input type="tel" name="phone" value={form.phone} onChange={onChange} required />
          </div>

          <div className="input-group">
            <label>Address:</label>
            <input type="text" name="address" value={form.address} onChange={onChange} required />
          </div>

          <div className="input-group">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={onChange}
              required
            />
          </div>

          <button className="submit-btn" type="submit">
            Register
          </button>
        </form>

        <div style={{ marginTop: 15, textAlign: "center", fontSize: 14 }}>
          Already have an account? <Link to="/login">Login here</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;