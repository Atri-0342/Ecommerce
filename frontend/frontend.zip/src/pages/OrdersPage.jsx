// import { useEffect, useState } from "react";
// import { useSelector, useDispatch } from "react-redux";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
// import L from "leaflet";
// import "leaflet/dist/leaflet.css";
// import "leaflet-routing-machine";
// import { 
//   Container, 
//   Button, 
//   Card, 
//   Row, 
//   Col 
// } from "react-bootstrap";
// import Navigation from "../components/Navigation"
// import Footer from "../components/Footer"
// // Fix for default marker icons
// import markerIcon from "leaflet/dist/images/marker-icon.png";
// import markerShadow from "leaflet/dist/images/marker-shadow.png";
// let DefaultIcon = L.icon({ 
//   iconUrl: markerIcon, 
//   shadowUrl: markerShadow, 
//   iconSize: [25, 41], 
//   iconAnchor: [12, 41] 
// });
// L.Marker.prototype.options.icon = DefaultIcon;

// // ✅ CLEAN ROAD ROUTING (No Text Panel)
// const RoutingMachine = ({ from, to }) => {
//   const map = useMap();

//   useEffect(() => {
//     if (!map || !from || !to) return;

//     const routingControl = L.Routing.control({
//       waypoints: [L.latLng(from[0], from[1]), L.latLng(to[0], to[1])],
//       lineOptions: { styles: [{ color: "#0d6efd", weight: 5, opacity: 0.8 }] },
//       show: false,                // Hides the instructions panel
//       addWaypoints: false,
//       routeWhileDragging: false,
//       draggableWaypoints: false,
//       fitSelectedRoutes: true,
//       createGeocoder: () => null, // Removes search box if present
//       containerClassName: 'd-none' // 🔥 Absolute fix: hides the instruction box container
//     }).addTo(map);

//     return () => map.removeControl(routingControl);
//   }, [map, from, to]);

//   return null;
// };

// const OrdersPage = () => {
//   const API = import.meta.env.VITE_API_URL;
//   const user = useSelector((state) => state.auth.user);
//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   const [orders, setOrders] = useState([]);
//   const [search, setSearch] = useState("");
//   const [showSidebar, setShowSidebar] = useState(false);
//   const [showMap, setShowMap] = useState(false);
//   const [loadingMap, setLoadingMap] = useState(false);

//   const [systemCoords, setSystemCoords] = useState(null);
//   const [userCoords, setUserCoords] = useState(null);

//   const statusSteps = ["Ordered", "Packed", "Shipped", "Delivered"];

//   useEffect(() => {
//     if (!user?._id) return;
//     axios.get(`${API}/orders/user/${user._id}`).then(res => {
//         const sortedOrders = res.data.orders ? [...res.data.orders].reverse() : [];
//         setOrders(sortedOrders);
//     });
//   }, [user, API]);

//   const handleLiveTrack = async (order) => {
//     setLoadingMap(true);
//     navigator.geolocation.getCurrentPosition(async (pos) => {
//       setSystemCoords([pos.coords.latitude, pos.coords.longitude]);
//       try {
//         const query = encodeURIComponent(order.shipAddress);
//         const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}`);
//         const data = await res.json();
//         if (data?.[0]) {
//           setUserCoords([parseFloat(data[0].lat), parseFloat(data[0].lon)]);
//           setShowMap(true);
//         }
//       } catch (e) { console.error(e); }
//       setLoadingMap(false);
//     }, () => setLoadingMap(false));
//   };

//   const filtered = orders.filter(o => 
//     o.items.some(i => i.product?.product_name.toLowerCase().includes(search.toLowerCase()))
//   );

//   return (
//     <div className="bg-light min-vh-100 ">
//       <Navigation/>

//       <Container className="py-5">
//         <h3 className="fw-bold mb-4">Track Purchases</h3>
//         {filtered.length === 0 && <p className="text-muted text-center py-5">No orders found.</p>}
        
//         {filtered.map(order => {
//           const currentIdx = statusSteps.indexOf(order.status || "Ordered");
//           return (
//             <Card className="border-0 shadow-sm rounded-4 p-4 mb-4 overflow-hidden" key={order._id}>
//               <Row className="align-items-center">
//                 <Col md={2} xs={4}>
//                   <img 
//                     src={`${API}${order.items[0]?.product?.image}`} 
//                     className="img-fluid rounded-3 shadow-sm border" 
//                     alt="product" 
//                     style={{ width: '100%', height: '100px', objectFit: 'cover'}}
//                   />
//                 </Col>
//                 <Col md={6} xs={8}>
//                   <h5 className="fw-bold mb-1 text-truncate">
//                     {order.items.map(i => i.product?.product_name).join(", ")}
//                   </h5>
//                   <p className="text-muted small mb-0">Total: ₹{order.total} • Order ID: {order._id.slice(-6).toUpperCase()}</p>
                  
//                   {/* ✅ FIXED STEPPER UI */}
//                   <div className="position-relative mt-4 mb-5" style={{ maxWidth: '420px' }}>
//                     {/* Background Progress Bar */}
//                     <div className="position-absolute w-100 bg-secondary-subtle" 
//                          style={{ height: '3px', top: '6px', zIndex: 1 }}>
//                       <div className="bg-primary h-100" 
//                            style={{ width: `${(currentIdx / 3) * 100}%`, transition: '0.6s cubic-bezier(0.4, 0, 0.2, 1)' }}>
//                       </div>
//                     </div>

//                     {/* Step Dots & Labels */}
//                     <div className="d-flex justify-content-between">
//                       {statusSteps.map((step, i) => (
//                         <div key={step} className="position-relative" style={{ zIndex: 2 }}>
//                           {/* Circle Dot */}
//                           <div 
//                             className={`rounded-circle border border-2 border-white shadow-sm ${i <= currentIdx ? 'bg-primary' : 'bg-secondary-subtle'}`} 
//                             style={{ width: '15px', height: '15px' }}
//                           ></div>
                          
//                           {/* Label (Centered exactly under dot) */}
//                           <div className="position-absolute translate-middle-x start-50 pt-2 text-center" style={{ width: '70px' }}>
//                             <span className={`d-block fw-bold ${i <= currentIdx ? 'text-primary' : 'text-muted opacity-50'}`} 
//                                   style={{ fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
//                               {step}
//                             </span>
//                           </div>
//                         </div>
//                       ))}
//                     </div>
//                   </div>
//                 </Col>
                
//                 <Col md={4} className="text-md-end mt-3 mt-md-0">
//                   {order.status === "Shipped" ? (
//                     <Button variant="primary" className="rounded-pill px-4 shadow-sm fw-bold border-0" onClick={() => handleLiveTrack(order)} disabled={loadingMap}>
//                       {loadingMap ? "Connecting..." : "Live Route 🛣️"}
//                     </Button>
//                   ) : order.status === "Delivered" ? (
//                     <span className="badge bg-success-subtle text-success px-4 py-2 rounded-pill fw-bold">✓ Delivered</span>
//                   ) : (
//                     <p className="small text-muted mb-0 fst-italic bg-light p-2 rounded">Tracker available when Shipped</p>
//                   )}
//                 </Col>
//               </Row>
//             </Card>
//           );
//         })}
//       </Container>

//       {/* ✅ CLEAN MAP MODAL */}
//       {showMap && systemCoords && userCoords && (
//         <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(5px)', zIndex: 1050 }} onClick={() => setShowMap(false)}>
//           <div className="modal-dialog modal-lg modal-dialog-centered" onClick={e => e.stopPropagation()}>
//             <div className="modal-content border-0 rounded-4 overflow-hidden shadow-lg">
//               <div className="p-3 d-flex justify-content-between align-items-center bg-white border-bottom">
//                 <h6 className="fw-bold mb-0">Delivery Intelligence <span className="badge bg-primary-subtle text-primary ms-2">Live Road Path</span></h6>
//                 <button className="btn-close" onClick={() => setShowMap(false)}></button>
//               </div>
//               <div style={{ height: "480px" }}>
//                 <MapContainer center={systemCoords} zoom={13} style={{ height: "100%" }}>
//                   <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
//                   <Marker position={systemCoords}></Marker>
//                   <Marker position={userCoords}></Marker>
//                   <RoutingMachine from={systemCoords} to={userCoords} />
//                 </MapContainer>
//               </div>
//               <div className="p-3 bg-light text-center small text-muted">
//                 <i className="bi bi-info-circle me-1"></i> 
//                 Real-time road visualization calculated via OSM routing.
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//             <Footer/>
//     </div>
//   );
// };

// export default OrdersPage;
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { MapContainer, TileLayer, Marker, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-routing-machine";
import { 
  Container, 
  Button, 
  Card, 
  Row, 
  Col,
  Form,
  InputGroup
} from "react-bootstrap";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";

// Fix for default marker icons
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

let DefaultIcon = L.icon({ 
  iconUrl: markerIcon, 
  shadowUrl: markerShadow, 
  iconSize: [25, 41], 
  iconAnchor: [12, 41] 
});
L.Marker.prototype.options.icon = DefaultIcon;

// ✅ CLEAN ROAD ROUTING COMPONENT
const RoutingMachine = ({ from, to }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !from || !to) return;

    const routingControl = L.Routing.control({
      waypoints: [L.latLng(from[0], from[1]), L.latLng(to[0], to[1])],
      lineOptions: { 
        styles: [{ color: "#0d6efd", weight: 5, opacity: 0.8 }],
        extendToWaypoints: true,
        missingRouteTolerance: 0
      },
      show: false,
      addWaypoints: false,
      routeWhileDragging: false,
      draggableWaypoints: false,
      fitSelectedRoutes: true,
      createGeocoder: () => null,
      containerClassName: 'd-none' // Hides the instruction panel
    }).addTo(map);

    return () => {
      if (map && routingControl) {
        map.removeControl(routingControl);
      }
    };
  }, [map, from, to]);

  return null;
};

const OrdersPage = () => {
  const API = import.meta.env.VITE_API_URL;
  const user = useSelector((state) => state.auth.user);
  const navigate = useNavigate();

  const [orders, setOrders] = useState([]);
  const [search, setSearch] = useState("");
  const [showMap, setShowMap] = useState(false);
  const [loadingMap, setLoadingMap] = useState(false);

  const [systemCoords, setSystemCoords] = useState(null); // Vendor/Warehouse Location
  const [userCoords, setUserCoords] = useState(null);     // Customer Shipping Location

  const statusSteps = ["Ordered", "Packed", "Shipped", "Delivered"];

  useEffect(() => {
    if (!user?._id) {
        navigate("/login");
        return;
    };
    
    axios.get(`${API}/orders/user/${user._id}`)
      .then(res => {
        const sortedOrders = res.data.orders ? [...res.data.orders].reverse() : [];
        setOrders(sortedOrders);
      })
      .catch(err => console.error("Error fetching orders:", err));
  }, [user, API, navigate]);

  const handleLiveTrack = async (order) => {
    setLoadingMap(true);
    
    // 1. Get current location (Simulating Driver/Warehouse position)
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const driverLat = pos.coords.latitude;
        const driverLon = pos.coords.longitude;
        setSystemCoords([driverLat, driverLon]);

        try {
          // 2. Geocode the shipping address
          const query = encodeURIComponent(order.shipAddress);
          const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}`);
          const data = await res.json();
          
          if (data && data.length > 0) {
            setUserCoords([parseFloat(data[0].lat), parseFloat(data[0].lon)]);
            setShowMap(true);
          } else {
            alert("Could not locate shipping address on map.");
          }
        } catch (e) {
          console.error("Geocoding error:", e);
        } finally {
          setLoadingMap(false);
        }
      },
      (err) => {
        console.error("Geolocation error:", err);
        setLoadingMap(false);
        alert("Please enable location services to track the delivery.");
      }
    );
  };

  const filtered = orders.filter(o => 
    o.items.some(i => i.product?.product_name.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="bg-light min-vh-100 d-flex flex-column">
      <Navigation />

      <Container className="py-5 flex-grow-1">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
          <h3 className="fw-bold mb-0">Track Purchases</h3>
          
          <InputGroup style={{ maxWidth: '350px' }}>
            <Form.Control
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded-start-pill border-0 shadow-sm"
            />
            <Button variant="white" className="rounded-end-pill border-0 shadow-sm bg-white text-muted">
              🔍
            </Button>
          </InputGroup>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-5">
            <p className="text-muted fs-5">No orders found matches your search.</p>
          </div>
        ) : (
          filtered.map(order => {
            const currentIdx = statusSteps.indexOf(order.status || "Ordered");
            
            return (
              <Card className="border-0 shadow-sm rounded-4 p-4 mb-4 overflow-hidden" key={order._id}>
                <Row className="align-items-center">
                  <Col md={2} xs={4}>
                    <img 
                      src={`${API}${order.items[0]?.product?.image}`} 
                      className="img-fluid rounded-3 shadow-sm border" 
                      alt="product" 
                      style={{ width: '100%', height: '110px', objectFit: 'cover'}}
                    />
                  </Col>
                  
                  <Col md={6} xs={8}>
                    <h5 className="fw-bold mb-1 text-truncate">
                      {order.items.map(i => i.product?.product_name).join(", ")}
                    </h5>
                    <p className="text-muted small mb-0">
                      Total: **₹{order.total}** • Order ID: {order._id.slice(-6).toUpperCase()}
                    </p>
                    
                    {/* PROGRESS STEPPER */}
                    <div className="position-relative mt-4 mb-5" style={{ maxWidth: '420px' }}>
                      <div className="position-absolute w-100 bg-secondary-subtle" 
                           style={{ height: '3px', top: '7px', zIndex: 1 }}>
                        <div className="bg-primary h-100" 
                             style={{ 
                               width: `${(currentIdx / (statusSteps.length - 1)) * 100}%`, 
                               transition: '0.6s cubic-bezier(0.4, 0, 0.2, 1)' 
                             }}>
                        </div>
                      </div>

                      <div className="d-flex justify-content-between">
                        {statusSteps.map((step, i) => (
                          <div key={step} className="position-relative" style={{ zIndex: 2 }}>
                            <div 
                              className={`rounded-circle border border-2 border-white shadow-sm ${i <= currentIdx ? 'bg-primary' : 'bg-secondary-subtle'}`} 
                              style={{ width: '16px', height: '16px' }}
                            ></div>
                            <div className="position-absolute translate-middle-x start-50 pt-2 text-center" style={{ width: '70px' }}>
                              <span className={`d-block fw-bold ${i <= currentIdx ? 'text-primary' : 'text-muted opacity-50'}`} 
                                    style={{ fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                                {step}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Col>
                  
                  <Col md={4} className="text-md-end mt-3 mt-md-0">
                    {order.status === "Shipped" ? (
                      <Button 
                        variant="primary" 
                        className="rounded-pill px-4 shadow-sm fw-bold border-0" 
                        onClick={() => handleLiveTrack(order)} 
                        disabled={loadingMap}
                      >
                        {loadingMap ? "Locating..." : "Live Route 🛣️"}
                      </Button>
                    ) : order.status === "Delivered" ? (
                      <span className="badge bg-success-subtle text-success px-4 py-2 rounded-pill fw-bold border border-success border-opacity-10">
                        ✓ Delivered
                      </span>
                    ) : (
                      <div className="small text-muted mb-0 fst-italic bg-light p-2 rounded border inline-block">
                        Tracker available when Shipped
                      </div>
                    )}
                  </Col>
                </Row>
              </Card>
            );
          })
        )}
      </Container>

      {/* ✅ ROAD PATH MODAL */}
      {showMap && systemCoords && userCoords && (
        <div className="modal d-block" style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)', zIndex: 1050 }} onClick={() => setShowMap(false)}>
          <div className="modal-dialog modal-lg modal-dialog-centered" onClick={e => e.stopPropagation()}>
            <div className="modal-content border-0 rounded-4 overflow-hidden shadow-lg">
              <div className="p-3 d-flex justify-content-between align-items-center bg-white border-bottom">
                <div>
                    <h6 className="fw-bold mb-0">Delivery Route</h6>
                    <small className="text-muted">Fastest road path to your address</small>
                </div>
                <button className="btn-close" onClick={() => setShowMap(false)}></button>
              </div>
              <div style={{ height: "500px", width: "100%" }}>
                <MapContainer center={systemCoords} zoom={13} style={{ height: "100%", width: "100%" }}>
                  <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                  <Marker position={systemCoords}></Marker>
                  <Marker position={userCoords}></Marker>
                  <RoutingMachine from={systemCoords} to={userCoords} />
                </MapContainer>
              </div>
              <div className="p-3 bg-white text-center small text-muted border-top">
                <span className="me-3">🔵 Driver Location</span>
                <span>🚩 Delivery Point</span>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <Footer />
    </div>
  );
};

export default OrdersPage;