import { useState, useEffect } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import { setAccessToken, setUser } from "../store/authSlice";
import "./pages.css";

const OtpLogin = () => {
  const API = import.meta.env.VITE_API_URL;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);

  // ✅ Auto-fill email coming from Login.jsx
  useEffect(() => {
    if (location.state?.email) {
      setEmail(location.state.email);
    }
  }, [location]);

  // ✅ STEP 1: Send OTP
  const sendOtp = async () => {
    if (!email) return alert("Enter your email");

    try {
      await axios.post(`${API}/users/login-with-email`, { email });
      setOtpSent(true);
      alert("OTP sent to your email!");
    } catch (err) {
      alert(err?.response?.data?.message || "Error sending OTP");
    }
  };

  // ✅ STEP 2: Verify OTP
  const verifyOtp = async () => {
    if (!otp) return alert("Enter OTP");

    try {
      const res = await axios.post(`${API}/users/verify-email-otp`, {
        email,
        otp,
      });

      dispatch(setAccessToken(res.data.accessToken));
      dispatch(setUser(res.data.user));
      navigate("/");
    } catch (err) {
      alert(err?.response?.data?.message || "Invalid OTP");
    }
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <h3 className="title">Login with Email OTP</h3>

        {/* ✅ EMAIL INPUT ALWAYS VISIBLE */}
        <div className="input-group">
          <label>Email:</label>
          <input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        {/* ✅ BEFORE OTP SENT */}
        {!otpSent && (
          <button
            className="submit-btn"
            style={{ background: "#2563eb" }}
            onClick={sendOtp}
          >
            Send OTP
          </button>
        )}

        {/* ✅ AFTER OTP SENT */}
        {otpSent && (
          <>
            <div className="input-group" style={{ marginTop: "15px" }}>
              <label>Enter OTP:</label>
              <input
                type="text"
                placeholder="6-digit OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
            </div>

            <button
              className="submit-btn"
              style={{ background: "#059669" }}
              onClick={verifyOtp}
            >
              Verify OTP
            </button>

            {/* ✅ Resend button */}
            <button
              className="submit-btn"
              style={{
                marginTop: "10px",
                background: "#ff9900",
              }}
              onClick={sendOtp}
            >
              Resend OTP
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default OtpLogin;