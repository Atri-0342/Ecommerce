import { useEffect, useState } from "react";
import axios from "axios";

const Admin = () => {
  const API = import.meta.env.VITE_API_URL;

  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [activeTab, setActiveTab] = useState("products");
  const [searchTerm, setSearchTerm] = useState("");

  const [modal, setModal] = useState(false);
  const [edit, setEdit] = useState(false);
  const [id, setId] = useState(null);

  const [form, setForm] = useState({
    product_name: "",
    price: "",
    description: "",
    stock: "",
    image: null,
  });

  const statusSteps = ["Ordered", "Packed", "Shipped", "Delivered"];

  const loadData = async () => {
    try {
      const [prodRes, orderRes] = await Promise.all([
        axios.get(`${API}/products`),
        axios.get(`${API}/orders/all`)
      ]);
      setProducts(prodRes?.data?.products ?? []);
      setOrders(orderRes?.data?.orders ?? []);
    } catch (err) {
      console.error("Load error:", err.message);
    }
  };

  useEffect(() => { loadData(); }, []);

  // Calculation for Stats Cards
  const totalRevenue = orders.reduce((acc, curr) => acc + (curr.total || 0), 0);
  const pendingOrders = orders.filter(o => o.status !== "Delivered").length;

  // --- PRODUCT LOGIC ---
  const openModal = (product = null) => {
    if (product) {
      setEdit(true);
      setId(product._id);
      setForm({ ...product, image: product.image });
    } else {
      setEdit(false);
      setId(null);
      setForm({ product_name: "", price: "", description: "", stock: "", image: null });
    }
    setModal(true);
  };

  const onHandleProduct = async (e) => {
    e.preventDefault();
    const fd = new FormData();
    Object.keys(form).forEach(key => {
      if (key === 'image') {
        if (form.image && typeof form.image !== "string") fd.append("image", form.image);
      } else {
        fd.append(key, form[key]);
      }
    });

    try {
      if (edit) await axios.put(`${API}/products/${id}`, fd);
      else await axios.post(`${API}/products/create`, fd);
      setModal(false);
      loadData();
    } catch (err) { alert("Error saving product"); }
  };

  const deleteProduct = async (pid) => {
    if (window.confirm("Are you sure? This will remove the item from inventory.")) {
      await axios.delete(`${API}/products/${pid}`);
      loadData();
    }
  };

  // --- ORDER LOGIC ---
  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await axios.put(`${API}/orders/status/${orderId}`, { status: newStatus });
      loadData();
    } catch (err) { alert("Failed to update status"); }
  };

  // Filtered Lists
  const filteredProducts = products.filter(p => p.product_name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="container-fluid py-4 bg-light min-vh-100">
      {/* Header & Navigation */}
      <div className="px-3 mb-4">
        <div className="d-flex justify-content-between align-items-end">
          <div>
            <h2 className="fw-bold text-dark mb-1">Admin Control Center</h2>
            <p className="text-muted small">Manage your store inventory and track customer deliveries</p>
          </div>
          <div className="btn-group shadow-sm bg-white p-1 rounded">
            <button className={`btn btn-sm px-4 ${activeTab === 'products' ? 'btn-primary' : 'btn-light'}`} onClick={() => setActiveTab('products')}>Inventory</button>
            <button className={`btn btn-sm px-4 ${activeTab === 'orders' ? 'btn-primary' : 'btn-light'}`} onClick={() => setActiveTab('orders')}>Orders ({pendingOrders})</button>
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="row g-3 px-3 mb-4">
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3">
            <small className="text-muted fw-bold text-uppercase">Total Revenue</small>
            <h3 className="fw-bold mb-0 text-success">₹{totalRevenue.toLocaleString()}</h3>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3">
            <small className="text-muted fw-bold text-uppercase">Total Products</small>
            <h3 className="fw-bold mb-0 text-primary">{products.length}</h3>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm p-3">
            <small className="text-muted fw-bold text-uppercase">Active Orders</small>
            <h3 className="fw-bold mb-0 text-warning">{pendingOrders}</h3>
          </div>
        </div>
      </div>

      {activeTab === "products" ? (
        <div className="mx-3">
          <div className="d-flex justify-content-between align-items-center mb-3">
            <input 
              type="text" 
              className="form-control w-25 shadow-sm border-0" 
              placeholder="Search products..." 
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button className="btn btn-dark px-4" onClick={() => openModal()}>+ Add New Item</button>
          </div>
          <div className="card shadow-sm border-0 overflow-hidden">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="bg-dark text-white">
                  <tr>
                    <th className="ps-4 py-3">Product</th>
                    <th>Price</th>
                    <th>Stock Status</th>
                    <th className="text-end pe-4">Manage</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((pro) => (
                    <tr key={pro._id}>
                      <td className="ps-4">
                        <div className="d-flex align-items-center">
                          <img src={`${API}${pro.image}`} className="rounded me-3 shadow-sm" style={{ width: "48px", height: "48px", objectFit: "cover" }} alt="" />
                          <div>
                            <div className="fw-bold">{pro.product_name}</div>
                            <small className="text-muted d-block text-truncate" style={{maxWidth: '200px'}}>{pro.description}</small>
                          </div>
                        </div>
                      </td>
                      <td className="fw-semibold text-dark">₹{pro.price}</td>
                      <td>
                        <span className={`badge ${pro.stock < 5 ? "bg-danger" : "bg-light text-dark border"}`}>
                          {pro.stock} left
                        </span>
                      </td>
                      <td className="text-end pe-4">
                        <button className="btn btn-light btn-sm border me-2" onClick={() => openModal(pro)}>Edit</button>
                        <button className="btn btn-outline-danger btn-sm" onClick={() => deleteProduct(pro._id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="mx-3">
          <div className="card shadow-sm border-0">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-primary text-dark">
                  <tr>
                    <th className="ps-4 py-3">Order Details</th>
                    <th>Purchased Items</th>
                    <th>Total Paid</th>
                    <th>Shipping To</th>
                    <th>Tracking</th>
                    <th className="text-end pe-4">Update Status</th>
                  </tr>
                </thead>
                <tbody>
                  {[...orders].reverse().map((order) => (
                    <tr key={order._id}>
                      <td className="ps-4">
                        <div className="fw-bold">{order.user?.name || "Guest User"}</div>
                        <small className="text-muted">{new Date(order.createdAt).toLocaleDateString()}</small>
                      </td>
                      <td className="small">
                        {order.items.map((i,idx) => (
                          <div key={idx} className="text-truncate" style={{maxWidth: '150px'}}>• {i.product?.product_name || 'Deleted Product'}</div>
                        ))}
                      </td>
                      <td className="fw-bold text-success">₹{order.total}</td>
                      <td className="small text-muted" style={{ maxWidth: "180px" }}>{order.shipAddress}</td>
                      <td>
                        <span className={`badge rounded-pill px-3 py-2 ${
                          order.status === 'Delivered' ? 'bg-success-subtle text-success' : 
                          order.status === 'Shipped' ? 'bg-info-subtle text-info' : 'bg-warning-subtle text-warning'
                        }`}>
                          {order.status || "Ordered"}
                        </span>
                      </td>
                      <td className="text-end pe-4">
                        <select 
                          className="form-select form-select-sm border-primary"
                          style={{width: '130px', display: 'inline-block'}}
                          value={order.status || "Ordered"}
                          onChange={(e) => updateOrderStatus(order._id, e.target.value)}
                        >
                          {statusSteps.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- REFINED PRODUCT MODAL --- */}
      {modal && (
        <div className="modal show d-block" style={{ backgroundColor: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}>
           <div className="modal-dialog modal-dialog-centered modal-lg">
            <div className="modal-content border-0 shadow-lg">
              <div className="modal-header bg-dark text-white border-0">
                <h5 className="modal-title fw-bold">{edit ? "Edit Listing" : "Create New Listing"}</h5>
                <button type="button" className="btn-close btn-close-white" onClick={() => setModal(false)}></button>
              </div>
              <form onSubmit={onHandleProduct}>
                <div className="modal-body p-4">
                  <div className="row g-4">
                    <div className="col-md-7">
                      <div className="mb-3">
                        <label className="form-label fw-bold small text-uppercase">Product Name</label>
                        <input type="text" className="form-control bg-light" value={form.product_name} onChange={(e) => setForm({...form, product_name: e.target.value})} required />
                      </div>
                      <div className="row mb-3">
                        <div className="col">
                          <label className="form-label fw-bold small text-uppercase">Price (₹)</label>
                          <input type="number" className="form-control bg-light" value={form.price} onChange={(e) => setForm({...form, price: e.target.value})} required />
                        </div>
                        <div className="col">
                          <label className="form-label fw-bold small text-uppercase">Stock</label>
                          <input type="number" className="form-control bg-light" value={form.stock} onChange={(e) => setForm({...form, stock: e.target.value})} required />
                        </div>
                      </div>
                      <div className="mb-3">
                        <label className="form-label fw-bold small text-uppercase">Description</label>
                        <textarea className="form-control bg-light" rows="4" value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} required></textarea>
                      </div>
                    </div>
                    <div className="col-md-5">
                       <label className="form-label fw-bold small text-uppercase text-center w-100">Media Upload</label>
                       <div className="border border-2 border-dashed rounded p-3 text-center bg-light mb-3" style={{minHeight: '200px'}}>
                          {form.image ? (
                            <img 
                              src={typeof form.image === "string" ? `${API}${form.image}` : URL.createObjectURL(form.image)} 
                              className="img-fluid rounded shadow-sm" style={{ maxHeight: "180px" }} alt="preview" 
                            />
                          ) : (
                            <div className="py-5 text-muted small">No image selected</div>
                          )}
                       </div>
                       <input type="file" className="form-control form-control-sm" onChange={(e) => setForm({ ...form, image: e.target.files[0] })} />
                    </div>
                  </div>
                </div>
                <div className="modal-footer border-0 p-4">
                  <button type="button" className="btn btn-light px-4" onClick={() => setModal(false)}>Cancel</button>
                  <button type="submit" className="btn btn-primary px-5 shadow-sm">{edit ? "Save Changes" : "Publish Product"}</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;