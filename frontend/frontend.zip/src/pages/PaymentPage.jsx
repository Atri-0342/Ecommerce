// import { useLocation, useNavigate } from "react-router-dom";
// import { useSelector } from "react-redux";
// import { useState, useEffect } from "react";
// import axios from "axios";

// const PaymentPage = () => {
//   const { state } = useLocation();
//   const navigate = useNavigate();
//   const API = import.meta.env.VITE_API_URL;
  
//   const user = useSelector((state) => state.auth.user);
//   const access = useSelector((state) => state.auth.accessToken);

//   const [useDefaultAddress, setUseDefaultAddress] = useState(true);
//   const [customAddress, setCustomAddress] = useState("");
//   const [loading, setLoading] = useState(false);

//   // Redirect if no state (direct URL access) or not logged in
//   useEffect(() => {
//     if (!state) navigate("/cart");
//     if (!access) navigate("/login");
//   }, [state, access, navigate]);

//   if (!state || !user) return (
//     <div className="container py-5 text-center">
//       <div className="spinner-border text-primary" role="status"></div>
//       <h2 className="mt-3">Processing...</h2>
//     </div>
//   );

//   const { cart, total } = state;

//   const handleConfirmOrder = async () => {
//     const finalAddress = useDefaultAddress ? user.address : customAddress;

//     if (!finalAddress || finalAddress.trim() === "") {
//       return alert("Please provide a valid shipping address");
//     }

//     setLoading(true);

//     const orderData = {
//       user: user._id,
//       userName: user.name,
//       userEmail: user.email,
//       userPhone: user.phone,
//       items: cart.map(item => ({
//         product: item._id,
//         product_name: item.product_name, 
//         quantity: item.qty,
//         price: item.price
//       })),
//       total,
//       shipAddress: finalAddress,
//       payment: "paid" // Assuming payment logic is handled
//     };

//     try {
//       const config = {
//         headers: { Authorization: `Bearer ${access}` }
//       };

//       await axios.post(`${API}/orders/create`, orderData, config);
      
//       alert("Order placed successfully! Check your email for the receipt.");
      
//       // Clear cart from storage after successful order
//       localStorage.removeItem("cart");
      
//       navigate("/orders");
//     } catch (err) {
//       alert(err.response?.data?.message || "Order failed. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="container py-5">
//       <div className="row justify-content-center">
//         <div className="col-lg-8">
//           <div className="card shadow-sm border-0 rounded-4 p-4">
//             <h2 className="fw-bold mb-4">Checkout</h2>
            
//             {/* Order Summary */}
//             <div className="bg-light p-3 rounded-3 mb-4">
//               <h5 className="fw-bold border-bottom pb-2">Order Summary</h5>
//               {cart.map(item => (
//                 <div key={item._id} className="d-flex align-items-center justify-content-between py-2">
//                   <div className="d-flex align-items-center">
//                     <img 
//                       src={item.image.startsWith('http') ? item.image : `${API}${item.image}`} 
//                       alt={item.product_name} 
//                       width="50" 
//                       height="50"
//                       className="rounded me-3 object-fit-cover" 
//                     />
//                     <div>
//                       <p className="mb-0 fw-semibold">{item.product_name}</p>
//                       <small className="text-muted">Qty: {item.qty}</small>
//                     </div>
//                   </div>
//                   <span className="fw-bold">₹{item.price * item.qty}</span>
//                 </div>
//               ))}
//               <div className="d-flex justify-content-between mt-3 pt-2 border-top">
//                 <h5 className="fw-bold">Total Amount:</h5>
//                 <h5 className="fw-bold text-success">₹{total}</h5>
//               </div>
//             </div>

//             {/* Address Selection */}
//             <div className="mb-4">
//               <h5 className="fw-bold mb-3">Shipping Address</h5>
              
//               {/* Default Address Option */}
//               <div 
//                 className={`form-check p-3 border rounded-3 mb-2 transition-all ${useDefaultAddress ? 'border-primary bg-light' : ''}`} 
//                 style={{cursor: 'pointer'}}
//                 onClick={() => setUseDefaultAddress(true)}
//               >
//                 <input 
//                   className="form-check-input ms-0 me-2" 
//                   type="radio" 
//                   checked={useDefaultAddress} 
//                   readOnly 
//                 />
//                 <label className="form-check-label fw-semibold" style={{cursor: 'pointer'}}>
//                   Use Registered Address
//                   <p className="small text-muted mb-0">{user?.address || "No address found in profile"}</p>
//                 </label>
//               </div>

//               {/* Custom Address Option */}
//               <div 
//                 className={`form-check p-3 border rounded-3 transition-all ${!useDefaultAddress ? 'border-primary bg-light' : ''}`} 
//                 style={{cursor: 'pointer'}}
//                 onClick={() => setUseDefaultAddress(false)}
//               >
//                 <input 
//                   className="form-check-input ms-0 me-2" 
//                   type="radio" 
//                   checked={!useDefaultAddress} 
//                   readOnly 
//                 />
//                 <label className="form-check-label fw-semibold" style={{cursor: 'pointer'}}>
//                   Use Different Address
//                 </label>
//                 {!useDefaultAddress && (
//                   <textarea 
//                     className="form-control mt-2 shadow-sm" 
//                     placeholder="Enter full delivery address..." 
//                     rows="3"
//                     value={customAddress}
//                     onChange={(e) => setCustomAddress(e.target.value)}
//                     onClick={(e) => e.stopPropagation()}
//                     autoFocus
//                   ></textarea>
//                 )}
//               </div>
//             </div>

//             {/* Action Button */}
//             <button 
//               className="btn btn-success btn-lg w-100 fw-bold py-3 rounded-3 shadow-sm" 
//               onClick={handleConfirmOrder}
//               disabled={loading}
//             >
//               {loading ? (
//                 <>
//                   <span className="spinner-border spinner-border-sm me-2"></span>
//                   Processing...
//                 </>
//               ) : (
//                 `Confirm & Pay ₹${total}`
//               )}
//             </button>

//             <div className="text-center mt-3">
//               <small className="text-muted">
//                 Order confirmation will be sent to: <br/>
//                 <span className="text-dark fw-bold">{user?.email}</span>
//               </small>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PaymentPage;



import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { useState, useEffect } from "react";
import axios from "axios";

const PaymentPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const API = import.meta.env.VITE_API_URL;
  
  const user = useSelector((state) => state.auth.user);
  const access = useSelector((state) => state.auth.accessToken);

  const [useDefaultAddress, setUseDefaultAddress] = useState(true);
  const [customAddress, setCustomAddress] = useState("");
  const [loading, setLoading] = useState(false);

  // 1. Redirect logic
  useEffect(() => {
    if (!state) {
      navigate("/cart");
      return;
    }
    // We only redirect to login if we are sure there is no access token
    if (access === null) {
      navigate("/login");
    }
  }, [state, access, navigate]);

  // 2. Loading Guard (Wait for Redux user data)
  if (!state || !user) {
    return (
      <div className="container py-5 text-center">
        <div className="spinner-border text-primary" role="status"></div>
        <h2 className="mt-3">Processing Order Details...</h2>
      </div>
    );
  }

  const { cart, total } = state;

  const handleConfirmOrder = async () => {
    const finalAddress = useDefaultAddress ? user.address : customAddress;

    if (!finalAddress || finalAddress.trim() === "") {
      return alert("Please provide a valid shipping address");
    }

    setLoading(true);

    // const orderData = {
    //   user: user._id,
    //   userName: user.name,
    //   userEmail: user.email,
    //   userPhone: user.phone,
    //   items: cart.map(item => ({
    //     product: item._id,
    //     product_name: item.product_name, 
    //     quantity: item.qty,
    //     price: item.price
    //   })),
    //   total,
    //   shipAddress: finalAddress,
    //   payment: "paid" 
    // };
const orderData = {
  user: user._id,           // Match: user
  userEmail: user.email,    // Match: userEmail
  userName: user.name,      // Match: userName
  userPhone: user.phone,    // Match: userPhone
  items: cart.map(item => ({
    product: item._id,      // Match: item.product (used in Product.findById)
    quantity: item.qty,     // Match: item.quantity (used in stock reduction)
    price: item.price
  })),
  total: total,             // Match: total
  shipAddress: finalAddress,// Match: shipAddress
  payment: "Paid"           // Match: payment
};
    try {
      const config = {
        headers: { Authorization: `Bearer ${access}` }
      };

      // Ensure your backend matches this route (/orders/create)
      await axios.post(`${API}/orders/create`, orderData, config);
      
      alert("Order placed successfully!");
      localStorage.removeItem("cart");
      navigate("/orders");
    } catch (err) {
      alert(err.response?.data?.message || "Order failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card shadow-sm border-0 rounded-4 p-4">
            <h2 className="fw-bold mb-4">Checkout</h2>
            
            {/* Order Summary */}
            <div className="bg-light p-3 rounded-3 mb-4">
              <h5 className="fw-bold border-bottom pb-2">Order Summary</h5>
              {cart.map(item => (
                <div key={item._id} className="d-flex align-items-center justify-content-between py-2">
                  <div className="d-flex align-items-center">
                    <img 
                      src={item.image.startsWith('http') ? item.image : `${API}${item.image}`} 
                      alt={item.product_name} 
                      width="50" 
                      height="50"
                      className="rounded me-3 object-fit-cover" 
                    />
                    <div>
                      <p className="mb-0 fw-semibold">{item.product_name}</p>
                      <small className="text-muted">Qty: {item.qty}</small>
                    </div>
                  </div>
                  <span className="fw-bold">₹{item.price * item.qty}</span>
                </div>
              ))}
              <div className="d-flex justify-content-between mt-3 pt-2 border-top">
                <h5 className="fw-bold">Total Amount:</h5>
                <h5 className="fw-bold text-success">₹{total}</h5>
              </div>
            </div>

            {/* Address Selection */}
            <div className="mb-4">
              <h5 className="fw-bold mb-3">Shipping Address</h5>
              
              <div 
                className={`form-check p-3 border rounded-3 mb-2 transition-all ${useDefaultAddress ? 'border-primary bg-light' : ''}`} 
                style={{cursor: 'pointer'}}
                onClick={() => setUseDefaultAddress(true)}
              >
                <input 
                  className="form-check-input ms-0 me-2" 
                  type="radio" 
                  checked={useDefaultAddress} 
                  readOnly 
                />
                <label className="form-check-label fw-semibold" style={{cursor: 'pointer'}}>
                  Use Registered Address
                  <p className="small text-muted mb-0">{user?.address || "No address found"}</p>
                </label>
              </div>

              <div 
                className={`form-check p-3 border rounded-3 transition-all ${!useDefaultAddress ? 'border-primary bg-light' : ''}`} 
                style={{cursor: 'pointer'}}
                onClick={() => setUseDefaultAddress(false)}
              >
                <input 
                  className="form-check-input ms-0 me-2" 
                  type="radio" 
                  checked={!useDefaultAddress} 
                  readOnly 
                />
                <label className="form-check-label fw-semibold" style={{cursor: 'pointer'}}>
                  Use Different Address
                </label>
                {!useDefaultAddress && (
                  <textarea 
                    className="form-control mt-2 shadow-sm" 
                    placeholder="Enter full delivery address..." 
                    rows="3"
                    value={customAddress}
                    onChange={(e) => setCustomAddress(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                  ></textarea>
                )}
              </div>
            </div>

            <button 
              className="btn btn-success btn-lg w-100 fw-bold py-3 rounded-3 shadow-sm" 
              onClick={handleConfirmOrder}
              disabled={loading}
            >
              {loading ? "Processing..." : `Confirm & Pay ₹${total}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentPage;
