// import { useState } from "react";
// import { useNavigate, Link } from "react-router-dom";
// import axios from "axios";
// import { useDispatch } from "react-redux";
// import { setAccessToken, setUser } from "../store/authSlice";
// import "./pages.css";

// const Login = () => {
//   const API = import.meta.env.VITE_API_URL;
//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   const [form, setForm] = useState({
//     email: "",
//     password: "",
//   });

//   const onChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   // ✅ Normal Password Login
//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     if (!form.email || !form.password) {
//       alert("Please fill email and password");
//       return;
//     }

//     try {
//       const res = await axios.post(`${API}/users/login`, form, {
//         withCredentials: true,
//       });

//       dispatch(setAccessToken(res.data.accessToken));
//       dispatch(setUser(res.data.user));

//       navigate("/");
//     } catch (err) {
//       alert(err?.response?.data?.message || "Invalid credentials.");
//     }
//   };

//   // ✅ OTP Login Request
//   const handleOtpLogin = async () => {
//     if (!form.email) {
//       alert("Enter your email first");
//       return;
//     }

//     try {
//       await axios.post(`${API}/users/login-with-email`, {
//         email: form.email,
//       });

//       navigate("/otp-login", { state: { email: form.email } });
//     } catch (err) {
//       alert(err?.response?.data?.message || "Failed to send OTP");
//     }
//   };

//   return (
//     <>
//       <div className="login-page">
//         <div className="login-box">
//           <h3 className="title">Login</h3>

//           <form onSubmit={handleSubmit}>
//             <div className="input-group">
//               <label>Email:</label>
//               <input
//                 type="email"
//                 name="email"
//                 value={form.email}
//                 onChange={onChange}
//                 placeholder="you@example.com"
//               />
//             </div>

//             <div className="input-group">
//               <label>Password:</label>
//               <input
//                 type="password"
//                 name="password"
//                 value={form.password}
//                 onChange={onChange}
//                 placeholder="••••••••"
//               />
//             </div>

//             {/* ✅ Password Login */}
//             <button className="submit-btn" type="submit">
//               Login
//             </button>

//             {/* ✅ OTP Login */}
//             <button
//   type="button"
//   className="submit-btn"
//   style={{ background: "#059669", marginTop: "12px" }}
//   onClick={handleOtpLogin}
// >
//   Login with Email OTP
// </button>
//           </form>

//           <div style={{ marginTop: 12, textAlign: "center", fontSize: 14 }}>
//             Don’t have an account? <Link to="/register">Register</Link>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default Login;
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import "./pages.css";
import React from "react";

const Login = () => {
  const API = import.meta.env.VITE_API_URL;
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const onChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.email || !form.password) {
      alert("Please fill email and password");
      return;
    }

    try {
      const res = await axios.post(
        `${API}/users/login`,   // ✅ FIXED
        form,
        { withCredentials: true }
      );

      alert(res.data.message);

      // 🔐 GO TO OTP PAGE (IMPORTANT)
      navigate("/verify-login", {
        state: { email: form.email }
      });

    } catch (err) {
      console.error(err);
      alert(
        err?.response?.data?.message || "Login failed. Please check your credentials."
      );
    }
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <h3 className="title">Login</h3>

        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={onChange}
              placeholder="you@example.com"
            />
          </div>

          <div className="input-group">
            <label>Password:</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={onChange}
              placeholder="••••••••"
            />
          </div>

          <button className="submit-btn" type="submit">
            Login
          </button>
        </form>

        <div style={{ marginTop: 12, textAlign: "center", fontSize: 14 }}>
          Don’t have an account?{" "}
          <Link to="/register">Register</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;