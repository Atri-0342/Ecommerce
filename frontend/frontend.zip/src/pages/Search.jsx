import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

// ✅ Redux Logout
import { useDispatch } from "react-redux";
import { logout } from "../store/authSlice";

// ✅ React Bootstrap
import {
  Navbar,
  Nav,
  Container,
  Row,
  Col,
  Card,
  Button,
  Form
} from "react-bootstrap";

import Offcanvas from "react-bootstrap/Offcanvas";

const Search = () => {
  const API = import.meta.env.VITE_API_URL;
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const initialQuery = location.state?.query || "";

  const [products, setProducts] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [query, setQuery] = useState(initialQuery);

  // ✅ Navbar and Filter Sidebar
  const [showSidebar, setShowSidebar] = useState(false); // navbar sidebar
  const [showFilters, setShowFilters] = useState(false); // mobile filters

  // ✅ Filters
  const [priceRange, setPriceRange] = useState([0, 999999]);
  const [category, setCategory] = useState("");
  const [brand, setBrand] = useState("");
  const [rating, setRating] = useState("");

  // ✅ Load products
  useEffect(() => {
    async function load() {
      try {
        const res = await axios.get(`${API}/products`);
        setProducts(res.data.products||[]);
        setFiltered(res.data.products);
      } catch (err) {
        console.log(err);
      }
    }
    load();
  }, []);

  // ✅ STARS
  const renderStars = (rating) => {
    const r = Number(rating) || 0; // null/undefined/NaN → 0
    return "★".repeat(r) + "☆".repeat(5 - r);
  };

  // ✅ Apply Filters
  const applyFilters = () => {
    let result = [...products];

    // Search Keywords
    result = result.filter((p) =>
      `${p.product_name} ${p.brand} ${p.category}`
        .toLowerCase()
        .includes(query.toLowerCase())
    );

    // Price Range
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    if (category) result = result.filter((p) => p.category === category);
    if (brand) result = result.filter((p) => p.brand === brand);
    if (rating) result = result.filter((p) => p.rating >= rating);

    setFiltered(result);
  };

  useEffect(() => {
    applyFilters();
  }, [query, priceRange, category, brand, rating]);

  // ✅ Dropdown lists
  const categories = [...new Set(products.map((p) => p.category))];
  const brands = [...new Set(products.map((p) => p.brand))];

  return (
    <div style={{ background: "#ffffff", minHeight: "100vh" }}>

      {/* ✅ NAVBAR */}
      <Navbar bg="light" expand="lg" className="shadow-sm px-3">

        <Navbar.Brand role="button" onClick={() => navigate("/")}>
          MyShop
        </Navbar.Brand>

        {/* ✅ MOBILE 3-BAR ICON */}
        <Button
          variant="light"
          className="border-0 d-lg-none"
          onClick={() => setShowSidebar(true)}
          style={{ fontSize: "28px", fontWeight: "900" }}
        >
          ☰
        </Button>

        {/* ✅ DESKTOP NAV */}
        <Nav className="ms-auto d-none d-lg-flex gap-2">
          <Button variant="outline-primary" onClick={() => navigate("/")}>Home</Button>
          <Button variant="outline-primary" onClick={() => navigate("/cart")}>Cart</Button>
          <Button variant="outline-primary" onClick={() => navigate("/orders")}>Orders</Button>
          <Button variant="outline-primary" onClick={() => navigate("/profile")}>Profile</Button>

          <Button
            variant="danger"
            onClick={() => { dispatch(logout()); navigate("/login"); }}
          >
            Logout
          </Button>
        </Nav>
      </Navbar>

      {/* ✅ MOBILE MENU SIDEBAR */}
      <Offcanvas show={showSidebar} onHide={() => setShowSidebar(false)} placement="end">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Menu</Offcanvas.Title>
        </Offcanvas.Header>

        <Offcanvas.Body>
          <Button className="w-100 mb-2" variant="outline-primary" onClick={() => navigate("/")}>Home</Button>
          <Button className="w-100 mb-2" variant="outline-primary" onClick={() => navigate("/cart")}>Cart</Button>
          <Button className="w-100 mb-2" variant="outline-primary" onClick={() => navigate("/orders")}>Orders</Button>
          <Button className="w-100 mb-2" variant="outline-primary" onClick={() => navigate("/profile")}>Profile</Button>

          <Button className="w-100" variant="danger" onClick={() => { dispatch(logout()); navigate("/login"); }}>
            Logout
          </Button>
        </Offcanvas.Body>
      </Offcanvas>

      {/* ✅ MAIN CONTENT */}
      <Container fluid className="mt-4">

        {/* ✅ MOBILE FILTERS BUTTON */}
        <div className="d-md-none text-center mb-3">
          <Button variant="secondary" onClick={() => setShowFilters(true)}>
            ☰ Filters
          </Button>
        </div>

        <Row>

          {/* ✅ DESKTOP FILTER SIDEBAR */}
          <Col md={3} className="border-end bg-white p-3 shadow-sm d-none d-md-block">
            <h4 className="mb-3">Filters</h4>

            {/* SEARCH */}
            <Form.Group className="mb-3">
              <Form.Label>Search</Form.Label>
              <Form.Control
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </Form.Group>

            {/* PRICE */}
            <Form.Group className="mb-3">
              <Form.Label>Price</Form.Label>
              <Row>
                <Col>
                  <Form.Control
                    type="number"
                    placeholder="Min"
                    onChange={(e) =>
                      setPriceRange([Number(e.target.value), priceRange[1]])
                    }
                  />
                </Col>
                <Col>
                  <Form.Control
                    type="number"
                    placeholder="Max"
                    onChange={(e) =>
                      setPriceRange([priceRange[0], Number(e.target.value)])
                    }
                  />
                </Col>
              </Row>
            </Form.Group>

            {/* CATEGORY */}
            <Form.Group className="mb-3">
              <Form.Label>Category</Form.Label>
              <Form.Select value={category} onChange={(e) => setCategory(e.target.value)}>
                <option value="">All</option>
                {categories.map((cat, i) => (
                  <option key={i} value={cat}>{cat}</option>
                ))}
              </Form.Select>
            </Form.Group>

            {/* BRAND */}
            <Form.Group className="mb-3">
              <Form.Label>Brand</Form.Label>
              <Form.Select value={brand} onChange={(e) => setBrand(e.target.value)}>
                <option value="">All</option>
                {brands.map((b, i) => (
                  <option key={i} value={b}>{b}</option>
                ))}
              </Form.Select>
            </Form.Group>

            {/* RATING */}
            <Form.Group className="mb-3">
              <Form.Label>Rating</Form.Label>
              <Form.Select value={rating} onChange={(e) => setRating(e.target.value)}>
                <option value="">All</option>
                <option value="1">1 ★+</option>
                <option value="2">2 ★+</option>
                <option value="3">3 ★+</option>
                <option value="4">4 ★+</option>
              </Form.Select>
            </Form.Group>
          </Col>

          {/* ✅ MOBILE FILTER OFFCANVAS */}
          <Offcanvas show={showFilters} onHide={() => setShowFilters(false)} placement="start">
            <Offcanvas.Header closeButton>
              <Offcanvas.Title>Filters</Offcanvas.Title>
            </Offcanvas.Header>

            <Offcanvas.Body>

              {/* SAME FILTERS AS DESKTOP */}
              <Form.Group className="mb-3">
                <Form.Label>Search</Form.Label>
                <Form.Control
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Price</Form.Label>
                <Row>
                  <Col>
                    <Form.Control
                      type="number"
                      placeholder="Min"
                      onChange={(e) =>
                        setPriceRange([Number(e.target.value), priceRange[1]])
                      }
                    />
                  </Col>
                  <Col>
                    <Form.Control
                      type="number"
                      placeholder="Max"
                      onChange={(e) =>
                        setPriceRange([priceRange[0], Number(e.target.value)])
                      }
                    />
                  </Col>
                </Row>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Category</Form.Label>
                <Form.Select value={category} onChange={(e) => setCategory(e.target.value)}>
                  <option value="">All</option>
                  {categories.map((cat, i) => (
                    <option key={i} value={cat}>{cat}</option>
                  ))}
                </Form.Select>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Brand</Form.Label>
                <Form.Select value={brand} onChange={(e) => setBrand(e.target.value)}>
                  <option value="">All</option>
                  {brands.map((b, i) =>
                    <option key={i} value={b}>{b}</option>
                  )}
                </Form.Select>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Rating</Form.Label>
                <Form.Select value={rating} onChange={(e) => setRating(e.target.value)}>
                  <option value="">All</option>
                  <option value="1">1 ★+</option>
                  <option value="2">2 ★+</option>
                  <option value="3">3 ★+</option>
                  <option value="4">4 ★+</option>
                </Form.Select>
              </Form.Group>

            </Offcanvas.Body>
          </Offcanvas>

          {/* ✅ PRODUCT GRID */}
          <Col md={9}>
            <h3>Results ({filtered.length})</h3>

            <Row className="mt-3">
              {filtered.map((p) => (
                <Col key={p._id} xs={6} md={4} lg={3} className="mb-4">
                  <Card className="shadow-sm h-100 bg-white">

                    <Card.Img
                      variant="top"
                      src={`${API}${p.image}`}
                      style={{ height: "150px", objectFit: "cover" }}
                    />

                    <Card.Body>
                      <Card.Title style={{ fontSize: "15px" }}>
                        {p.product_name}
                      </Card.Title>

                      {/* ✅ STARS */}
                      <div style={{ color: "#ffc107", fontSize: "16px" }}>
                        {renderStars(p.rating)}
                      </div>

                      <p className="text-primary fw-bold mt-1">₹ {p.price}</p>

                      <Button
                        variant="primary"
                        className="w-100"
                        onClick={() => navigate(`/booking/${p._id}`)}
                      >
                        View
                      </Button>
                    </Card.Body>

                  </Card>
                </Col>
              ))}
            </Row>

          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Search;