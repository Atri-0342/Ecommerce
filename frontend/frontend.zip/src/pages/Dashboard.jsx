// // import { useDispatch } from "react-redux";
// // import { logout } from "../store/authSlice";
// // import { useNavigate } from "react-router-dom";
// // import { useEffect, useState } from "react";
// // import axios from "axios";
// // import "./dashboard.css";
// // import Navigation from "../components/Navigation";
// // import Footer from "../components/Footer";
// // // ✅ React Bootstrap
// // import {
// //   Navbar,
// //   Nav,
// //   Container,
// //   Row,
// //   Col,
// //   Button,
// //   Card,
// //   Form,
// //   InputGroup
// // } from "react-bootstrap";

// // const Dashboard = () => {
// //   const dispatch = useDispatch();
// //   const API = import.meta.env.VITE_API_URL;
// //   const navigate = useNavigate();

// //   const [products, setProducts] = useState([]);
// //   const [search, setSearch] = useState("");
// //   const [showSidebar, setShowSidebar] = useState(false);

// //   useEffect(() => {
// //     async function load() {
// //       try {
// //         const res = await axios.get(`${API}/products/`);
// //         setProducts(res?.data?.products ?? []);
// //       } catch (err) {
// //         console.log(err.message);
// //       }
// //     }
// //     load();
// //   }, [API]);

// //   const visible = products.slice(0, 5);

// //   const goToSearch = () => {
// //     if (search.trim()) {
// //       navigate("/search", { state: { query: search } });
// //       setShowSidebar(false); // Close sidebar if searching from mobile
// //     }
// //   };

// //   const handleLogout = () => {
// //     dispatch(logout());
// //     navigate("/login");
// //   };

// //   return (
// //     <>
// //       <Navigation />

// //       {/* ✅ ================= ATTRACTIVE SEARCH HERO ================= */}
// //       <div className="hero-section">
// //         <Container>
// //           <Row className="justify-content-center text-center">
// //             <Col lg={8} xs={11}>
// //               <h1 className="display-4 fw-bold text-white mb-3 shadow-text hero-title">
// //                 Discover Your Style
// //               </h1>
// //               <p className="lead text-white-50 mb-4 mb-md-5 hero-subtitle">
// //                 Exclusive deals delivered to your doorstep.
// //               </p>
              
// //               <div className="search-box-wrapper mx-auto shadow-lg">
// //                 <InputGroup className="bg-white rounded-pill p-1">
// //                   <Form.Control
// //                     placeholder="Search products..."
// //                     className="border-0 ps-3 ps-md-4 py-2 py-md-3 rounded-pill shadow-none responsive-input"
// //                     value={search}
// //                     onChange={(e) => setSearch(e.target.value)}
// //                     onKeyDown={(e) => e.key === "Enter" && goToSearch()}
// //                   />
// //                   <Button 
// //                     variant="primary" 
// //                     className="rounded-pill px-3 px-md-5 fw-bold transition-all"
// //                     onClick={goToSearch}
// //                   >
// //                     Search
// //                   </Button>
// //                 </InputGroup>
// //               </div>
// //             </Col>
// //           </Row>
// //         </Container>
// //       </div>

// //       {/* ✅ ================= PRODUCT SECTIONS ================= */}
// //       <Container className="py-5">
// //         {['Categories', 'Trending', 'Suggested', 'All Products'].map((title, idx) => (
// //           <div key={idx} className="mb-5">
// //             <div className="d-flex justify-content-between align-items-end mb-4">
// //               <div>
// //                 <h2 className="fw-bold m-0 section-title">{title}</h2>
// //                 <div className="bg-primary rounded" style={{ height: "4px", width: "40px" }}></div>
// //               </div>
// //               <Button variant="link" className="text-decoration-none fw-bold p-0 text-primary">See All →</Button>
// //             </div>

// //             <Row className="g-3 g-md-4">
// //               {visible.map((p) => (
// //                 <Col key={p._id} xs={6} md={4} lg={3} xl={2}>
// //                   <Card 
// //                     className="h-100 border-0 shadow-sm modern-card"
// //                     onClick={() => navigate(`/booking/${p._id}`)}
// //                   >
// //                     <div className="card-img-container p-3">
// //                       <Card.Img src={`${API}${p.image}`} className="product-img" />
// //                     </div>
// //                     <Card.Body className="d-flex flex-column">
// //                       <Card.Title className="text-truncate h6 fw-bold mb-1">
// //                         {p.product_name}
// //                       </Card.Title>
// //                       <Card.Text className="text-primary fw-bold mb-2">₹{p.price}</Card.Text>
// //                       {title === 'All Products' && (
// //                         <Button variant="outline-primary" size="sm" className="w-100 rounded-pill py-1 mt-auto">View</Button>
// //                       )}
// //                     </Card.Body>
// //                   </Card>
// //                 </Col>
// //               ))}
// //             </Row>
// //           </div>
// //         ))}
// //       </Container>
// //       <Footer/>
// //     </>
// //   );
// // };

// // export default Dashboard;
// import { useDispatch, useSelector } from "react-redux";
// import { logout } from "../store/authSlice";
// import { useNavigate } from "react-router-dom";
// import { useEffect, useState, useRef } from "react";
// import axios from "axios";
// import "./dashboard.css";
// import Navigation from "../components/Navigation";
// import Footer from "../components/Footer";
// import { io } from "socket.io-client";
// // ✅ React Bootstrap
// import {
//   Container,
//   Row,
//   Col,
//   Button,
//   Card,
//   Form,
//   InputGroup
// } from "react-bootstrap";
// const socket = io("http://localhost:5000");
// const Dashboard = () => {
//   const dispatch = useDispatch();
//   const API = import.meta.env.VITE_API_URL;
//   const navigate = useNavigate();
// // ✅ Get user from Redux
//   const user = useSelector((state) => state.auth.user);
//   const [products, setProducts] = useState([]);
//   const [search, setSearch] = useState("");
// // ✅ Chat States
//   const [chat, setChat] = useState([]);
//   const [message, setMessage] = useState("");
//   const [openChat, setOpenChat] = useState(false);
//   const scrollRef = useRef(null);
//   useEffect(() => {
//     async function load() {
//       try {
//         const res = await axios.get(`${API}/products/`);
//         const fetchedProducts = res?.data?.products || res?.data || [];
//         setProducts(fetchedProducts);
//       } catch (err) {
//         console.error("Fetch Error:", err.message);
//       }
//     }
//     load();
//   }, [API]);

//   const goToSearch = () => {
//     if (search.trim()) {
//       navigate("/search", { state: { query: search } });
//     }
//   };

//   const handleProductClick = (id) => {
//     navigate(`/product/${id}`);
//   };

//   // ✅ Data logic for different sections
//   const trendingProducts = products.slice(0, 6); // First 6
//   const suggestedProducts = [...products].reverse().slice(0, 6); // Last 6 (reversed)
//   const allProducts = products; // Full list

//   return (
//     <>
//       <Navigation />

//       {/* 🚀 HERO SECTION */}
//       <div className="hero-section text-center py-5 bg-primary text-white mb-5">
//         <Container>
//           <h1 className="display-4 fw-bold">Discover Your Style</h1>
//           <p className="lead mb-4">Exclusive deals delivered to your doorstep.</p>
//           <div className="mx-auto" style={{ maxWidth: "600px" }}>
//             <InputGroup className="bg-white rounded-pill p-1 shadow-lg">
//               <Form.Control
//                 placeholder="Search products..."
//                 className="border-0 ps-4 shadow-none rounded-pill"
//                 value={search}
//                 onChange={(e) => setSearch(e.target.value)}
//                 onKeyDown={(e) => e.key === "Enter" && goToSearch()}
//               />
//               <Button variant="dark" className="rounded-pill px-4" onClick={goToSearch}>
//                 Search
//               </Button>
//             </InputGroup>
//           </div>
//         </Container>
//       </div>

//       <Container>
//         {/* 🔥 TRENDING SECTION */}
//         <section className="mb-5">
//           <SectionHeader title="Trending Now" onSeeAll={() => navigate('/search')} />
//           <ProductGrid items={trendingProducts} API={API} onClick={handleProductClick} />
//         </section>

//         {/* ✨ SUGGESTED SECTION */}
//         <section className="mb-5">
//           <SectionHeader title="Suggested for You" onSeeAll={() => navigate('/search')} />
//           <ProductGrid items={suggestedProducts} API={API} onClick={handleProductClick} />
//         </section>

//         {/* 📦 ALL PRODUCTS SECTION */}
//         <section className="mb-5">
//           <SectionHeader title="All Products" onSeeAll={() => navigate('/search')} />
//           <ProductGrid items={allProducts} API={API} onClick={handleProductClick} showViewBtn={true} />
//         </section>
//       </Container>
      
//       <Footer/>
//     </>
//   );
// };

// // ✅ Sub-Component for Section Headers
// const SectionHeader = ({ title, onSeeAll }) => (
//   <div className="d-flex justify-content-between align-items-center mb-4">
//     <h2 className="fw-bold m-0" style={{ borderLeft: "5px solid #007bff", paddingLeft: "15px" }}>
//       {title}
//     </h2>
//     <Button variant="link" onClick={onSeeAll} className="text-decoration-none fw-bold">
//       See All →
//     </Button>
//   </div>
// );

// // ✅ Sub-Component for the Product Grid
// const ProductGrid = ({ items, API, onClick, showViewBtn }) => (
//   <Row className="g-4">
//     {items.map((p) => (
//       <Col key={p._id} xs={6} md={4} lg={3} xl={2}>
//         <Card 
//           className="h-100 border-0 shadow-sm modern-card"
//           style={{ cursor: "pointer", transition: "transform 0.2s" }}
//           onClick={() => onClick(p._id)}
//           onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.02)"}
//           onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
//         >
//           <div className="p-3 text-center" style={{ height: "160px" }}>
//             <Card.Img 
//               src={p.image ? `${API}${p.image}` : "/placeholder.jpg"} 
//               className="h-100 w-100" 
//               style={{ objectFit: "contain" }}
//             />
//           </div>
//           <Card.Body className="d-flex flex-column text-center">
//             <Card.Title className="text-truncate h6 fw-bold mb-1">{p.product_name}</Card.Title>
//             <Card.Text className="text-primary fw-bold mb-2">₹{p.price}</Card.Text>
//             {showViewBtn && (
//               <Button variant="outline-primary" size="sm" className="mt-auto rounded-pill">
//                 View
//               </Button>
//             )}
//           </Card.Body>
//         </Card>
//       </Col>
//     ))}
//   </Row>
// );

// export default Dashboard;
import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "../store/authSlice";
import axios from "axios";
import { io } from "socket.io-client";

// ✅ Styles
import "./dashboard.css";

// ✅ Components
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";

// ✅ React Bootstrap
import {
  Container,
  Row,
  Col,
  Button,
  Card,
  Form,
  InputGroup
} from "react-bootstrap";

// Initialize socket outside component to avoid multiple connections
const socket = io("http://localhost:5000");

const Dashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const API = import.meta.env.VITE_API_URL;
  
  // ✅ Get user from Redux store
  const user = useSelector((state) => state.auth.user);

  // ✅ Product States
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");

  // ✅ Chat States
  const [chat, setChat] = useState([]);
  const [message, setMessage] = useState("");
  const [openChat, setOpenChat] = useState(false);
  const scrollRef = useRef(null);

  // 📦 1. Load Products on Mount
  useEffect(() => {
    async function load() {
      try {
        const res = await axios.get(`${API}/products/`);
        const fetchedProducts = res?.data?.products || res?.data || [];
        setProducts(fetchedProducts);
      } catch (err) {
        console.error("Fetch Error:", err.message);
      }
    }
    load();
  }, [API]);

  // 🔥 2. CHAT LOGIC: Load History & Real-time Sync
  useEffect(() => {
    if (!user?._id) return;

    // Fetch existing chat history from database
    const fetchHistory = async () => {
      try {
        const res = await axios.get(`${API}/messages/${user._id}`);
        setChat(res.data);
      } catch (err) {
        console.error("Chat History Error:", err);
      }
    };
    fetchHistory();

    // Listen for incoming messages (from user or bot)
    socket.on("receive_message", (data) => {
      setChat((prev) => [...prev, data]);
    });

    return () => socket.off("receive_message");
  }, [user?._id, API]);

  // ✨ 3. Auto-Welcome Trigger
  useEffect(() => {
    if (openChat && user?._id && chat.length === 0) {
      socket.emit("join_chat", { userId: user._id });
    }
  }, [openChat, user?._id, chat.length]);

  // 📜 4. Auto-scroll to bottom of chat
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat]);

  // ✉️ 5. Send Message
  const sendMessage = () => {
    if (!message.trim() || !user?._id) return;
    socket.emit("send_message", { text: message, userId: user._id });
    setMessage("");
  };

  // 🗑️ 6. Reset Chat History
  const handleResetChat = async () => {
    if (!user?._id) return;
    if (window.confirm("Restart conversation and clear history?")) {
      try {
        await axios.delete(`${API}/messages/clear/${user._id}`);
        setChat([]); // Immediate UI clear
        socket.emit("join_chat", { userId: user._id }); // Trigger new welcome
      } catch (err) {
        console.error("Reset failed:", err);
      }
    }
  };

  const goToSearch = () => {
    if (search.trim()) {
      navigate("/search", { state: { query: search } });
    }
  };

  const handleProductClick = (id) => {
    navigate(`/product/${id}`);
  };

  // Layout logic
  const trendingProducts = products.slice(0, 6);
  const suggestedProducts = [...products].reverse().slice(0, 6);
  const allProducts = products;

  return (
    <div className="dashboard-wrapper">
      <Navigation />

      {/* 🚀 HERO SECTION */}
      <div className="hero-section text-center py-5 bg-primary text-white mb-5 shadow-sm">
        <Container>
          <h1 className="display-4 fw-bold">Discover Your Style</h1>
          <p className="lead mb-4">Exclusive deals delivered to your doorstep.</p>
          <div className="mx-auto" style={{ maxWidth: "600px" }}>
            <InputGroup className="bg-white rounded-pill p-1 shadow-lg">
              <Form.Control
                placeholder="Search products..."
                className="border-0 ps-4 shadow-none rounded-pill"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && goToSearch()}
              />
              <Button variant="dark" className="rounded-pill px-4" onClick={goToSearch}>
                Search
              </Button>
            </InputGroup>
          </div>
        </Container>
      </div>

      <Container className="pb-5">
        {/* 🔥 TRENDING SECTION */}
        <section className="mb-5">
          <SectionHeader title="Trending Now" onSeeAll={() => navigate('/search')} />
          <ProductGrid items={trendingProducts} API={API} onClick={handleProductClick} />
        </section>

        {/* ✨ SUGGESTED SECTION */}
        <section className="mb-5">
          <SectionHeader title="Suggested for You" onSeeAll={() => navigate('/search')} />
          <ProductGrid items={suggestedProducts} API={API} onClick={handleProductClick} />
        </section>

        {/* 📦 ALL PRODUCTS SECTION */}
        <section className="mb-5">
          <SectionHeader title="All Products" onSeeAll={() => navigate('/search')} />
          <ProductGrid items={allProducts} API={API} onClick={handleProductClick} showViewBtn={true} />
        </section>
      </Container>

      {/* 🤖 CHATBOT OVERLAY */}
      <ChatBotUI 
        openChat={openChat} 
        setOpenChat={setOpenChat} 
        chat={chat} 
        message={message} 
        setMessage={setMessage} 
        sendMessage={sendMessage} 
        handleResetChat={handleResetChat}
        scrollRef={scrollRef}
      />

      <Footer />
    </div>
  );
};

// ================= SUB-COMPONENTS =================

const ChatBotUI = ({ openChat, setOpenChat, chat, message, setMessage, sendMessage, handleResetChat, scrollRef }) => (
  <>
    <Button
      onClick={() => setOpenChat(!openChat)}
      className="rounded-circle shadow-lg d-flex align-items-center justify-content-center chatbot-toggle"
      style={{
        position: "fixed", bottom: "30px", right: "30px",
        width: "60px", height: "60px", zIndex: 2000, fontSize: "24px"
      }}
    >
      {openChat ? "✖" : "💬"}
    </Button>

    {openChat && (
      <Card className="shadow-lg border-0 chatbot-card" style={{
        position: "fixed", bottom: "100px", right: "30px",
        width: "350px", height: "500px", zIndex: 2000, borderRadius: "15px"
      }}>
        <Card.Header className="bg-primary text-white d-flex justify-content-between align-items-center p-3" style={{ borderRadius: "15px 15px 0 0" }}>
          <span className="fw-bold">AtoZ Assistant 🤖</span>
          <Button variant="link" className="text-white p-0 text-decoration-none" onClick={handleResetChat} title="Reset Chat">
            🔄
          </Button>
        </Card.Header>
        
        <Card.Body className="overflow-auto bg-light chat-body-area" style={{ flex: "1" }}>
          {chat.map((msg, i) => (
            <div key={i} className={`d-flex mb-3 ${msg.sender === "user" ? "justify-content-end" : "justify-content-start"}`}>
              <div 
                className={`p-2 px-3 shadow-sm ${msg.sender === "user" ? "bg-primary text-white" : "bg-white text-dark"}`}
                style={{ 
                    borderRadius: msg.sender === "user" ? "18px 18px 0 18px" : "18px 18px 18px 0", 
                    maxWidth: "85%", fontSize: "14px" 
                }}
              >
                {msg.text}
              </div>
            </div>
          ))}
          <div ref={scrollRef} />
        </Card.Body>

        <Card.Footer className="bg-white border-0 p-3">
          <InputGroup>
            <Form.Control
              placeholder="Type a message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              className="rounded-start-pill border-light bg-light shadow-none"
            />
            <Button variant="primary" className="rounded-end-pill px-3" onClick={sendMessage}>
              Send
            </Button>
          </InputGroup>
        </Card.Footer>
      </Card>
    )}
  </>
);

const SectionHeader = ({ title, onSeeAll }) => (
  <div className="d-flex justify-content-between align-items-center mb-4 pt-4">
    <h2 className="fw-bold m-0" style={{ borderLeft: "5px solid #007bff", paddingLeft: "15px" }}>
      {title}
    </h2>
    <Button variant="link" onClick={onSeeAll} className="text-decoration-none fw-bold">
      See All →
    </Button>
  </div>
);

const ProductGrid = ({ items, API, onClick, showViewBtn }) => (
  <Row className="g-4">
    {items.map((p) => (
      <Col key={p._id} xs={6} md={4} lg={3} xl={2}>
        <Card 
          className="h-100 border-0 shadow-sm modern-card"
          onClick={() => onClick(p._id)}
        >
          <div className="p-3 text-center" style={{ height: "160px" }}>
            <Card.Img 
              src={p.image ? `${API}${p.image}` : "/placeholder.jpg"} 
              className="h-100 w-100" 
              style={{ objectFit: "contain" }}
            />
          </div>
          <Card.Body className="d-flex flex-column text-center">
            <Card.Title className="text-truncate h6 fw-bold mb-1">{p.product_name}</Card.Title>
            <Card.Text className="text-primary fw-bold mb-2 small">₹ {p.price}</Card.Text>
            {showViewBtn && (
              <Button variant="outline-primary" size="sm" className="mt-auto rounded-pill py-1">
                View Details
              </Button>
            )}
          </Card.Body>
        </Card>
      </Col>
    ))}
  </Row>
);

export default Dashboard;